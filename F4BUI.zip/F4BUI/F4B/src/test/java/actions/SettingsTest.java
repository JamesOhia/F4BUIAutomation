package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class SettingsTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();
	private int timer = 1000;

	@BeforeTest
	public void startUp() throws IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	public void General() throws InterruptedException, IOException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		//General
		settingsPageObject.ClickGeneral();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterNumber("8088730310");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.ChangePassword();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterOldPassword("Blonde77@1");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterNewPassword("Blonde77@111");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterConfirmPassword("Blonde77@111");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.CancelPassword();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 2)
	public void BankAccounts() throws InterruptedException, IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		//Bank Accounts
		settingsPageObject.BankAccounts();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.AddNewBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.EnterAccountNumber("0690000034");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(5000);

		settingsPageObject.SelectNigeria();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(5000);

		settingsPageObject.BankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.AccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickPrimaryAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickPrimaryAccount();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(5000);

		settingsPageObject.ClickCurrency();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickNGN();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.AddBank();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(4000);

		settingsPageObject.BankAdded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);


		settingsPageObject.EditBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.DeleteBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		settingsPageObject.BankDeleted();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		settingsPageObject.WaitingDelete1();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		settingsPageObject.WaitingDelete2();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);
		driver.close();

	}

	@Test(priority = 3)
	public void Users() throws InterruptedException, IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		//Users Tab
		settingsPageObject.UsersTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.InviteUser();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.EnterEmailUser("jamesohia4@gmail.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.SelectRole();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.SelectAdmin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickInviteUser();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.CancelInvite();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.RemoveUser();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.CancelUser();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.WaitingUser1();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		settingsPageObject.WaitingUser2();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);
		driver.close();

	}

	@Test(priority = 4)
	public void API() throws InterruptedException, IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		//API Tab
		settingsPageObject.CopyPublic();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.CopySecret();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.CopyEncryption();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);



		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);
		driver.close();

	}

	@Test(priority = 4)
	public void WebHooks() throws InterruptedException {


		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		//Webhook Tab
		settingsPageObject.WebHooksTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterUrl("www.google.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		settingsPageObject.EnterHash("google");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);



		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);
		driver.close();

	}

	@Test(priority = 5)
	public void AccountSettings() throws InterruptedException, IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		SettingsPageObject settingsPageObject= new SettingsPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.ClickSettingsTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		//Account Settings
		settingsPageObject.AccountTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.AccountTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.SelectCustomerPay();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.SelectMePay();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.TransactionEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.TransactionEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.TransactionCustomers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.TransactionCustomers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.PaymentMethod();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.PaymentMethod();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		settingsPageObject.SaveSettings();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		settingsPageObject.WaitingSettings();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);



		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

	}

		@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






