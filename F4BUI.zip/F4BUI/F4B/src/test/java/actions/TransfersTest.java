package actions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class TransfersTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();
	private int timer = 2000;


	
	@BeforeTest
	public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	public void LoginToTransferPage() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		homePageObject.ClickEmail();
		homePageObject.ClearEmail();
		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();
		homePageObject.ClearPassword();
		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.Overview();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfersNavigation();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test(priority = 2, dependsOnMethods="LoginToTransferPage")
	public void TransfersPage() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickToday();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickLast7Days();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickThirtyDays();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickOneYear();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Transfers Screen
		transfersPageObject.ClickTransfersNavigation();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickFilterBy();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickCurrencyFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickSelectedCurrency();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickDone();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickDownload();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


		@Test(priority = 3, dependsOnMethods="TransfersPage")
		public void AwaitingApprovalScreen() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickAwaitingApproval();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.AwaitingApprovalScreen();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);
	}



	@Test(priority = 4)
	public void CreateBeneficiariesSuccessful() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickBeneficiaries();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewBeneficiary();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickSelectCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNigeria();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickSelectBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickAccountNumber();
		transfersPageObject.ClearAccountNumber();
		transfersPageObject.EnterAccountNumber("0690000035");

		transfersPageObject.ClickAddBeneficiaryBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(4000);

		transfersPageObject.ClickAddBeneficiaryBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(4000);

		transfersPageObject.BeneficiaryAdded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(4000);


	}

	@Test(priority = 5, dependsOnMethods="CreateBeneficiariesSuccessful")
	public void CreateExistingBeneficiaries() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickBeneficiaries();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);

		transfersPageObject.ClickNewBeneficiary();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);

		transfersPageObject.ClickSelectCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickNigeria();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickSelectBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickAccountNumber();
		transfersPageObject.ClearAccountNumber();
		transfersPageObject.EnterAccountNumber("0690000035");

		transfersPageObject.ClickAddBeneficiaryBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.BeneficiaryExists();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickBenefCancelButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}

		@Test(priority = 6, dependsOnMethods="CreateExistingBeneficiaries")
	public void DeleteBeneficiary() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickBeneficiaries();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);

		transfersPageObject.ClickBeneficiaryAccountNumber();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickRemoveBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickRemoveBeneficiary();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.BeneficiaryDeleted();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test(priority = 7)
	public void FundingHistory() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickFundingHistory();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		transfersPageObject.ClickTopupBalance();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		transfersPageObject.ClickCopyButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		transfersPageObject.ClickFundWallet();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		transfersPageObject.ClickSelectUSD();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		//Logout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);


	}


	@Test(priority = 8)
	public void TransfersTestToSingleBankAccount_Success() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		homePageObject.ClickEmail();
		homePageObject.ClearEmail();
		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();
		homePageObject.ClearPassword();
		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.Overview();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfersNavigation();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		//Transfer to Single Bank Account
		transfersPageObject.ClickTransferToBankAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);


		transfersPageObject.ClickSingleTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmount();
		transfersPageObject.ClearAmount();
		transfersPageObject.EnterAmount("10000");

		transfersPageObject.ClickSelectBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccountNumberBA();
		transfersPageObject.ClearAccountNumberBA();
		transfersPageObject.EnterAccountNumberBA("0690000034");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickDescription();
		transfersPageObject.ClearDescription();
		transfersPageObject.EnterDescription("UI Test");

		transfersPageObject.ClickConfirmTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirm();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);

		transfersPageObject.ClickConfirm();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.TransferProcessing();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

	}

	@Test(priority = 9)
	public void TransferToSingleBankAccount_InvalidAccountDetails() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		//Invalid Account Details
		transfersPageObject.ClickTransferToBankAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickSingleTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmount();
		transfersPageObject.ClearAmount();
		transfersPageObject.EnterAmount("10000");

		transfersPageObject.ClickSelectBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccountNumberBA();
		transfersPageObject.ClearAccountNumberBA();
		transfersPageObject.EnterAccountNumberBA("1472136431");

		transfersPageObject.InvalidAccountDetails();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

	}

	@Test(priority = 10)
	public void TransferToSingleBankAccount_InsufficientFunds() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickAmount();
		transfersPageObject.ClearAmount();
		transfersPageObject.EnterAmount("200000000");

		transfersPageObject.InsufficientFundsError();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickHere();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		
		//Logout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

	}

		@Test(priority = 11)
		public void SingleTransfersTestToMobileMoney_Successful() throws InterruptedException {

			NavigateToURL startWebsite = new NavigateToURL(driver);

			startWebsite.launchURL();

			HomePageObject homePageObject = new HomePageObject(driver);
			TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

			homePageObject.ClickEmail();
			homePageObject.ClearEmail();
			homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

			homePageObject.ClickPassword();
			homePageObject.ClearPassword();
			homePageObject.EnterPassword("Blonde77@1");

			homePageObject.ClickLogin();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			transfersPageObject.ClickContinueToOldDashboard();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			homePageObject.TestModeMessageIsReturned();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.Overview();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickTransfers();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickTransfersNavigation();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickNewTransfer();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			//Single Transfer to Mobile Money
			transfersPageObject.ClickTransferToMobileMoney();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickSingleTransferMM();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickSelectCurrency();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(5000);

			transfersPageObject.ClickSelectGHS();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickAmountMM();
			transfersPageObject.ClearAmountMM();
			transfersPageObject.EnterAmountMM("500");

			transfersPageObject.ClickSelectNetwork();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickMTNMobile();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ScrollDownPage();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickPhoneNumberMM();
			transfersPageObject.ClearPhoneNumberMM();
			transfersPageObject.EnterPhoneNumberMM("233240974010");

			transfersPageObject.ScrollDownPage();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickBeneficiaryName();
			transfersPageObject.ClearBeneficiaryName();
			transfersPageObject.EnterBeneficiaryName("ZenithCrest");

			transfersPageObject.ClickDescriptionMM();
			transfersPageObject.ClearDescriptionMM();
			transfersPageObject.EnterDescriptionMM("Mobile Money Transfer UI Test");

			transfersPageObject.ScrollDownPage();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickConfirmTransferMM();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

			transfersPageObject.ClickConfirmMM();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			transfersPageObject.TransferProcessing();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(timer);

		}

	@Test(priority = 12)
	public void SingleTransfersTestToMobileMoney_InvalidAccountDetails() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransferToBankAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickSingleTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmount();
		transfersPageObject.ClearAmount();
		transfersPageObject.EnterAmount("10000");

		transfersPageObject.ClickSelectBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAccountNumberBA();
		transfersPageObject.ClearAccountNumberBA();
		transfersPageObject.EnterAccountNumberBA("06900000364");

		transfersPageObject.InvalidAccountDetails();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);
	}



	@Test(priority = 13)
	public void SingleTransfersTestToMobileMoney_InsufficientFunds() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickAmount();
		transfersPageObject.ClearAmount();
		transfersPageObject.EnterAmount("200000000");

		transfersPageObject.InsufficientFundsError();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		//Logout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

	}

	@Test(priority = 14)
	public void TransferToSingleBarterAccountSuccessful() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		homePageObject.ClickEmail();
		homePageObject.ClearEmail();
		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();
		homePageObject.ClearPassword();
		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.Overview();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfersNavigation();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		//Transfer to Single Barter Account
		transfersPageObject.ClickTransferToBarterAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickSingleTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickMobileNumber();
		transfersPageObject.ClearMobileNumber();
		transfersPageObject.EnterMobileNumber("08088730315");

		transfersPageObject.ClickAmountBA();
		transfersPageObject.ClearAmountBA();
		transfersPageObject.EnterAmountBA("500");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickDescriptionBA();
		transfersPageObject.ClearDescriptionBA();
		transfersPageObject.EnterDescriptionBA("Barter Account Transfer UI Test");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.TransferProcessing();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

	}

	@Test(priority = 15)
	public void TransferToSingleBarterAccountInsufficientFunds() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		//Transfer to Single Barter Account

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransferToBarterAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickSingleTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickMobileNumber();
		transfersPageObject.ClearMobileNumber();
		transfersPageObject.EnterMobileNumber("08088730315");

		transfersPageObject.ClickAmountBA();
		transfersPageObject.ClearAmountBA();
		transfersPageObject.EnterAmountBA("500000000000000000000");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickDescriptionBA();
		transfersPageObject.ClearDescriptionBA();
		transfersPageObject.EnterDescriptionBA("Barter Account Transfer UI Test");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.InsufficientFunds();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickCancelBtnBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		transfersPageObject.ScrollUpPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 16)
	public void SingleTransfersTestToMobileMoney_InvalidMobileNumber() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransferToBarterAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		/*
		transfersPageObject.ClickSingleTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);
		 */

		transfersPageObject.ClickMobileNumber();
		transfersPageObject.ClearMobileNumber();
		transfersPageObject.EnterMobileNumber("1234567899");

		transfersPageObject.ClickAmountBA();
		transfersPageObject.ClearAmountBA();
		transfersPageObject.EnterAmountBA("500");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickDescriptionBA();
		transfersPageObject.ClearDescriptionBA();
		transfersPageObject.EnterDescriptionBA("Barter Account Transfer UI Test");

		transfersPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmTransferBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.InvalidMobileNumber();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickCancelBtnBA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

	}

	@Test(priority = 17)
	public void TransferToFlutterwaveAccountSuccessful() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		homePageObject.ClickEmail();
		homePageObject.ClearEmail();
		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();
		homePageObject.ClearPassword();
		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		transfersPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.Overview();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfers();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransfersNavigation();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		//Transfer to Flutterwave Account
		transfersPageObject.ClickTransferToFlutterwaveAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmountFA();
		transfersPageObject.ClearAmountFA();
		transfersPageObject.EnterAmountFA("10000");

		transfersPageObject.ClickMerchantID();
		transfersPageObject.ClearMerchantID();
		transfersPageObject.EnterMerchantID("100557326");

		transfersPageObject.ClickTransactionNote();
		transfersPageObject.ClearTransactionNote();
		transfersPageObject.EnterTransactionNote("Transfer to Flutterwave Account UI test");


		transfersPageObject.ClickConfirmTransferFA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmTransferFA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickConfirmFA();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.TransferProcessing();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

	}

	@Test(priority = 18)
	public void TransferToFlutterwaveAccountInvalidMerchantID() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransferToFlutterwaveAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmountFA();
		transfersPageObject.ClearAmountFA();
		transfersPageObject.EnterAmountFA("10000");

		transfersPageObject.ClickMerchantID();
		transfersPageObject.ClearMerchantID();
		transfersPageObject.EnterMerchantID("000000000");

		transfersPageObject.InvalidMerchantID();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickGoBack();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);


	}

	@Test(priority = 19)
	public void TransferToFlutterwaveAccountInsufficientFunds() throws InterruptedException {

		HomePageObject homePageObject = new HomePageObject(driver);
		TransfersPageObject transfersPageObject = new TransfersPageObject(driver);

		transfersPageObject.ClickNewTransfer();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickTransferToFlutterwaveAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickAmountFA();
		transfersPageObject.ClearAmountFA();
		transfersPageObject.EnterAmountFA("100000000000000000");

		transfersPageObject.InsufficientFundsError();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		transfersPageObject.ClickHere();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);
	}

		@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






