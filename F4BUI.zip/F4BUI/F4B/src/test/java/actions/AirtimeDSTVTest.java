package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class AirtimeDSTVTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	public void SingleAirtimePurchaseNGN() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuyAirtimeButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimePurchase();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimePhoneNumberField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimePhoneNumber("7039426925");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimeAmountField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimeAmount("10:00");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuySingleAirtime();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.SingleAirtimePurchaseSuccessMessageIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);



	}

	@Test(priority = 2)
	public void SingleAirtimePurchaseGHS() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuyAirtimeButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimePurchase();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeGH();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimeNetworkMTN();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);


		airtimeDSTVObject.ClickSingleAirtimeNumberFieldGhs();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimeNumberFieldGhs("7039426926");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimeAmountField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimeAmount("10:00");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuySingleAirtime();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.SingleAirtimePurchaseSuccessMessageIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);


	}

	@Test(priority = 3)
	public void invalidPhoneNumber() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuyAirtimeButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimePurchase();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimePhoneNumberField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimePhoneNumber("0703942692");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimeAmountField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimeAmount("10:00");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuySingleAirtime();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.SingleAirtimeInvalidNumberIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

	}


	@Test(priority = 4)
	public void insufficientAmount() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuyAirtimeButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimePurchase();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimePhoneNumberField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimePhoneNumber("7039426925");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleAirtimeAmountField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleAirtimeAmount("1:00");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuySingleAirtime();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.SingleAirtimeInsufficientAmountIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

	}



	@Test(priority = 5)
	public void filterByDateAirtimePurchase() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject = new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject = new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterByTodayButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterBy7DaysButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterBy30DaysButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterByYearButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.ClickDateAirtimeFilterField1();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.EnterDateAirtimeFilterField1("2022-01-01");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickDateAirtimeFilterField2();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.EnterDateAirtimeFilterField2("2022-03-01");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

	}


	@Test(priority = 6)
	public void filterByCurrencyAirtimePurchase() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickCurrencyAirtimeFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeCurrencyFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleAirtimeCurrencyFilterDoneButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);


		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);


	}


	@Test(priority = 7)
	public void filterByPhoneNumberAirtimePurchase() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimeFilterByButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickPhoneNumberAirtimeFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);


		airtimeDSTVObject.EnterPhoneNumberAirtimeFilter("07039426925");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);


		airtimeDSTVObject.ClickFilterButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);


	}


	@Test(priority = 8)
	public void DownloadAirtime() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject = new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject = new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickAirtimePurchaseHeader();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);

		airtimeDSTVObject.ClickDownloadAirtimeButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		airtimeDSTVObject.DownloadAirtimeSuccessMessageIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}


		@Test(priority = 9)
		public void BulkAirtimePurchase() throws InterruptedException {

			NavigateToURL startWebsite = new NavigateToURL(driver);

			startWebsite.launchURL();


			HomePageObject homePageObject= new HomePageObject(driver);
			AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

			homePageObject.ClickEmail();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			homePageObject.ClearEmail();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

			homePageObject.ClickPassword();

			homePageObject.ClearPassword();

			homePageObject.EnterPassword("Blonde77@1");

			homePageObject.ClickLogin();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			homePageObject.ClickOldDashboard();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			homePageObject.TestModeMessageIsReturned();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(3000);

			airtimeDSTVObject.ClickAirtimeDSTVButton();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			airtimeDSTVObject.ClickAirtimePurchaseHeader();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			airtimeDSTVObject.ClickBuyAirtimeButton();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(2000);

			airtimeDSTVObject.ClickBulkAirtimePurchase();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(2000);

			airtimeDSTVObject.ClickBulkAirtimeUpload();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			airtimeDSTVObject.ClickBuyBulkAirtime();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

			airtimeDSTVObject.BulkAirtimeSuccessMessageIsDisplayed();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
			Thread.sleep(1000);

		}



	@Test(priority = 10)
	public void SingleDSTVPurchase() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		AirtimeDSTVObject airtimeDSTVObject= new AirtimeDSTVObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickAirtimeDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickDSTVSubscription();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickBuyDSTVSubscription();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleDSTVSubscription();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		airtimeDSTVObject.ClickSingleDSTVCountryField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleDSTVNGField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleDSTVAmountField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleDSTVAmountField("1000:00");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.ClickSingleDSTVSmartNumberField();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);

		airtimeDSTVObject.EnterSingleDSTVSmartNumber("0025401100");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		airtimeDSTVObject.ClickBuyDSTVButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);


		/*airtimeDSTVObject.BulkAirtimeSuccessMessageIsDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(1000);
*/


	}






	@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






