package actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class InvoicesTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();
	private final int timer = 2000;

	@BeforeTest
	public void startUp() throws IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();


		driver.manage().deleteAllCookies();


	}

	@Test(priority = 1)//Positive scenario
	public void LoginToInvoices() throws InterruptedException, IOException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);
		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;


		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;


		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		invoicePageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		invoicePageObject.ClickInvoicesTab();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=2, dependsOnMethods="LoginToInvoices")//Positive Scenario
	public void FilterInvoices() throws InterruptedException, IOException {
		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		//Filter Invoices
		invoicePageObject.ClickFilteredButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredToday();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredLast7Days();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFiltered30Days();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFiltered1Year();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilterDue();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredPaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredIssued();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredDraft();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickClearFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFiltered1Year();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		invoicePageObject.ClickFilteredFilter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

	}


	@Test (priority=3, dependsOnMethods="LoginToInvoices")//Negative Scenario

	public void CreateInvoiceNoEmail() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);
		//New Invoice
		invoicePageObject.ClickNewInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.ClickSendInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.NoEmailAddressInvoices();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}

	@Test (priority=4, dependsOnMethods="CreateInvoiceNoEmail")//Negative Scenario

	public void CreateInvoiceNoDescription() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);
		//New Invoice

		invoicePageObject.ClickEmailAddress();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.ClickDropDownEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ClickSendInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.NoInvoiceItem();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}

	@Test (priority=5, dependsOnMethods="CreateInvoiceNoDescription")//Positive Scenario

	public void CreateNewInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);
		//New Invoice


		invoicePageObject.ClickDueDate();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.SelectDueToday();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.ClickCurrency();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.SelectCurrency();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.EnterInvoiceItem("Laptop");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.EnterQuantity("2");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.EnterUnitPrice("100");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.EnterInvoiceNotes("This is a laptop");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.ScrollUp();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ClickSendInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(timer);

		invoicePageObject.InvoiceSent();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}

	/*@Test (priority=6, dependsOnMethods="LoginToInvoices")//Positive Scenario

	public void DownloadInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);
		driver.navigate().refresh();

		Thread.sleep(timer);
		//New Invoice
		invoicePageObject.DownloadInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		invoicePageObject.InvoiceDownloaded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}*/

	@Test (priority=7, dependsOnMethods="CreateNewInvoice")//Positive Scenario

	public void OpenCreatedInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);


			invoicePageObject.ClickCreatedInvoice();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}



	@Test (priority=8, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void DownloadCreatedInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.DownloadInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=9, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind14DaysBefore() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.ScrollDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.Invoice14DaysBefore();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=10, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind7DaysBefore() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.Invoice7DaysBefore();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=11, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind3DaysBefore() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.Invoice3DaysBefore();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=12, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void RemindOnDueDate() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.InvoiceOnDueDate();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=13, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind3DaysAfter() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.Invoice3DaysAfter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=14, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind7DaysAfter() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.Invoice7DaysAfter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=15, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void Remind14DaysAfter() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.Invoice14DaysAfter();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceReminded();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=16, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void ResendInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.ScrollUp();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(timer);

		invoicePageObject.EditInvoiceMenu();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ResendInvoiceMenu();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ScrollDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ResendInvoiceButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceResent();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=17, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void SaveInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);


		invoicePageObject.EditInvoiceMenu();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.EditInvoiceSelect();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ClickSaveInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceEdited();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=18, dependsOnMethods="OpenCreatedInvoice")//Positive Scenario

	public void EditInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.ClickCreatedInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.EditInvoiceMenu();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.EditInvoiceSelect();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ClearInvoiceItem();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.EnterInvoiceItem("Edited");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ClickSendInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=19, dependsOnMethods="OpenCreatedInvoice")//Negative Scenario

	public void MarkInvoiceAsPaidNoDate() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.ClickCreatedInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.ScrollDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.MarkAsPaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.SubmitPaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.NoDatePaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}

	@Test (priority=20, dependsOnMethods="MarkInvoiceAsPaidNoDate")//Positive Scenario

	public void MarkInvoiceAsPaid() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.EnterDatePaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.DateSelectPaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.SubmitPaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoicePaid();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=21, dependsOnMethods="MarkInvoiceAsPaid")//Positive Scenario

	public void SendReceipt() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.SendReceipt();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.PaymentReceiptSent();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test (priority=22, dependsOnMethods="SendReceipt")//Positive Scenario

	public void DeleteInvoice() throws InterruptedException, IOException {

		InvoicePageObject invoicePageObject= new InvoicePageObject(driver);

		invoicePageObject.DeleteInvoice();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		invoicePageObject.InvoiceDeleted();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}



		@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






