package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;
import java.util.Random;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class PaymentLinksTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();
	private final int timer = 1000;
	private int randNumber;
	private String randString;

	@BeforeTest
	public void startUp() throws IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
	}

	@Test(priority = 1)//Negative Scenario
	public void CreateSingleChargeNoName() throws InterruptedException {

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();


		HomePageObject homePageObject= new HomePageObject(driver);

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		homePageObject.EnterEmail("maurice.e@zenithcresttechnologies.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		homePageObject.ClickOldDashboard();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS) ;


		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;


		paymentLinksPageObject.NavigateDown();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		paymentLinksPageObject.ClickPaymentLinkTab();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS) ;


		//Create Single Charge Payment
		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickSingleCharge();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.NoNameErrorPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=2, dependsOnMethods="CreateSingleChargeNoName")//Negative Scenario
	public void CreateSingleChargeNoDescription() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterPaymentName("Single Charge");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.NoDescriptionPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=3, dependsOnMethods="CreateSingleChargeNoDescription")//Positive Scenario
	public void CreateSingleChargeNoAmount() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkCreated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=4, dependsOnMethods="CreateSingleChargeNoAmount")//Positive Scenario
	public void UpdateSinglePaymentLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.PaymentLinkDataClicked();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EditPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClearPaymentName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EnterPaymentName("Updated Single Charge");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.SaveEditedPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentPageEdited();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=5, dependsOnMethods="UpdateSinglePaymentLink")//Positive Scenario
	public void DeactivateSinglePaymentLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.WaitPaymentLinkUpdated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.DeactivatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeactivated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=6, dependsOnMethods="CreateSingleChargeNoAmount")//Positive Scenario
	public void DeleteInsideSinglePaymentLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.DeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ConfirmDeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeleted();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=7, dependsOnMethods="CreateSingleChargeNoAmount")//Positive Scenario
	public void CreateSingleChargePayment() throws InterruptedException {
		Random random = new Random();
		randNumber = random.nextInt(1000000000);
		randString = String.valueOf(randNumber);

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		//Create Single Charge Payment
		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickSingleCharge();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterPaymentName("Single Charge");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickCountryCode();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.SelectNGN();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterAmount("10000");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickMoreOptions();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterCustomURL(randString);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterRedirectLink("https://google.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterFieldName("Name of Field");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.LinkCreatedDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	/*@Test (priority=8, dependsOnMethods="CreateSingleChargePayment")//Positive Scenario
	public void CopySinglePaymentCharge() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickCopyLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=9, dependsOnMethods="CreateSingleChargePayment")//Positive Scenario
	public void DeleteSingleChargePayment() throws InterruptedException{
		HomePageObject homePageObject= new HomePageObject(driver);

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickDeleteLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ConfirmDelete();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(3000);

		
	}*/

	@Test (priority=10, dependsOnMethods="CreateSingleChargePayment")//Negative Scenario
	public void CreateSubscriptionNoName() throws InterruptedException, IOException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		//Create Subscription Link
		paymentLinksPageObject.ClickSubscriptionLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.NoNameErrorPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

	}

	@Test (priority=11, dependsOnMethods="CreateSubscriptionNoName")//Negative Scenario
	public void CreateSubscriptionNoDescription() throws InterruptedException, IOException {

		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterPaymentName("Subscription Link");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.NoDescriptionPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

	}

	@Test (priority=12, dependsOnMethods="CreateSubscriptionNoDescription")//Positive Scenario
	public void CreateSubscriptionNoAmount() throws InterruptedException, IOException {

		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkCreated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=13, dependsOnMethods="CreateSubscriptionNoAmount")//Positive Scenario
	public void UpdateSubscriptionLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.PaymentLinkDataClicked();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EditPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClearPaymentName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EnterPaymentName("Updated Subscription Link");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.SaveEditedPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentPageEdited();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=14, dependsOnMethods="UpdateSubscriptionLink")//Positive Scenario
	public void DeactivateSubscriptionLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.WaitPaymentLinkUpdated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.DeactivatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeactivated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=15, dependsOnMethods="UpdateSubscriptionLink")//Positive Scenario
	public void DeleteInsideSubscriptionLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.DeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ConfirmDeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeleted();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=16, dependsOnMethods="CreateSubscriptionNoName")//Positive Scenario
	public void CreateSubscriptionLink() throws InterruptedException, IOException {


		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);
		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		//Create Subscription Link
		paymentLinksPageObject.ClickSubscriptionLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.EnterPaymentName("Subscription Link");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickCountryCode();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.SelectNGN();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterAmount("1000");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.ClickInterval();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.SelectInterval();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.EnterChargeNumber("100");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.ClickCreateLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.LinkCreatedDisplayed();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	/*@Test (priority=17, dependsOnMethods="CreateSubscriptionLink")//Positive Scenario
	public void CopySubscriptionLink() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickCopyLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=18, dependsOnMethods="CreateSubscriptionLink")//Positive Scenario
	public void DeleteSubscriptionLink() throws InterruptedException{

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickDeleteLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		paymentLinksPageObject.ConfirmDelete();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;




	}*/

	@Test (priority=19, dependsOnMethods="CreateSingleChargePayment")
	public void CreateDonationNoName() throws InterruptedException, IOException {


		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		//Create Donation Link
		paymentLinksPageObject.ClickDonationPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.ClickCreatePage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.NoNameDonationPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=20, dependsOnMethods="CreateDonationNoName")//Negative Scenario
	public void CreateDonationNoDescription() throws InterruptedException, IOException {


		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterPageTitle("Page Title");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.ClickCreatePage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.NoDescriptionDonationPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=21, dependsOnMethods="CreateDonationNoDescription")//Positive Scenario
	public void CreateDonationNoAmount() throws InterruptedException, IOException {


		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClickCreatePage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.PageCreated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority=22, dependsOnMethods="CreateDonationNoAmount")//Positive Scenario
	public void UpdateDonationPage() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.PaymentLinkDataClicked();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EditPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ClearPaymentName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.EnterPaymentName("Updated Donation Page");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.SaveEditedPaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentPageEdited();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=23, dependsOnMethods="UpdateDonationPage")//Positive Scenario
	public void DeactivatePaymentPage() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.WaitPaymentLinkUpdated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.DeactivatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeactivated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=24, dependsOnMethods="UpdateDonationPage")//Positive Scenario
	public void DeleteInsidePaymentPage() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.DeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.ConfirmDeleteInsidePaymentButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		paymentLinksPageObject.PaymentLinkDeleted();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


	}

	@Test (priority=25, dependsOnMethods="CreateDonationNoName")//Positive Scenario
	public void CreateDonationPage() throws InterruptedException, IOException {
		Random random = new Random();
		randNumber = random.nextInt(1000000000);
		randString = String.valueOf(randNumber);
		HomePageObject homePageObject= new HomePageObject(driver);

		PaymentLinksPageObject paymentLinksPageObject = new PaymentLinksPageObject(driver);

		paymentLinksPageObject.CreatePaymentLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		//Create Donation Link
		paymentLinksPageObject.ClickDonationPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.EnterPageTitle("Page Title");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.ClickCountryCode();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.SelectNGN();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterAmount("100000");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterDescription("This is the description");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		

		paymentLinksPageObject.EnterDonationWebsite("https://google.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.EnterDonationPhoneNumber("08001234567");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		paymentLinksPageObject.ClickCreatePage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.PageCreated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		paymentLinksPageObject.WaitDonationLinkCreated();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);



	}

	/*@Test (priority=26, dependsOnMethods="CreateDonationPage")//Positive Scenario
	public void CopyPaymentPage() throws InterruptedException {

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickCopyLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;



	}

	@Test (priority=27, dependsOnMethods="CreateDonationPage")//Positive Scenario
	public void DeletePaymentPage() throws InterruptedException{
		HomePageObject homePageObject= new HomePageObject(driver);

		PaymentLinksPageObject paymentLinksPageObject= new PaymentLinksPageObject(driver);

		paymentLinksPageObject.ClickDeleteLink();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;


		paymentLinksPageObject.ConfirmDelete();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;

		//Signout
		homePageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(2000);

		homePageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

	}*/

		@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






