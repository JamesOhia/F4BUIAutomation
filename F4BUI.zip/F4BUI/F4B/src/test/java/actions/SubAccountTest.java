package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class SubAccountTest {
	private static WebDriver driver = null;
	private int timer = 3000;

	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {

		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	public void NGNSubAccountTest() throws InterruptedException {
		timer = 3000;

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		//TestNGNSubAccount
		HomePageObject homePageObject = new HomePageObject(driver);
		SubAccountPageObject SubAccountPageObject = new SubAccountPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.EnterEmail("emelia+2@flutterwavego.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickNewAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountName();
		SubAccountPageObject.ClearSubAccountName();
		SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

		SubAccountPageObject.ClickSubAccountEmail();
		SubAccountPageObject.ClearSubAccountEmail();
		SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

		SubAccountPageObject.ClickSubAccountCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickCountryNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickBankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccountNumberTab();
		SubAccountPageObject.ClearAccountNumberTab();
		SubAccountPageObject.EnterAccountNumber("0690000034");

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatPaymentShare();
		SubAccountPageObject.ClearFlatPaymentShare();
		SubAccountPageObject.EnterFlatPaymentShare("50");

		SubAccountPageObject.ClickCreateSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.MouseOver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickYesDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);



	}


	@Test(priority = 2)
	public void GHSubAccountTest() throws InterruptedException {
		timer = 3000;

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		//TestGHSubAccount
		HomePageObject homePageObject = new HomePageObject(driver);
		SubAccountPageObject SubAccountPageObject = new SubAccountPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.EnterEmail("emelia+2@flutterwavego.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);


		SubAccountPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickNewAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountName();
		SubAccountPageObject.ClearSubAccountName();
		SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

		SubAccountPageObject.ClickSubAccountEmail();
		SubAccountPageObject.ClearSubAccountEmail();
		SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

		SubAccountPageObject.ClickSubAccountCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickCountryGH();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickBankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBankGH();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBankGHBranch();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBankGHPLC();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccountNumberTab();
		SubAccountPageObject.ClearAccountNumberTab();
		SubAccountPageObject.EnterAccountNumber("0381626302511");

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatPaymentShare();
		SubAccountPageObject.ClearFlatPaymentShare();
		SubAccountPageObject.EnterFlatPaymentShare("50");

		SubAccountPageObject.ClickCreateSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.MouseOver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		SubAccountPageObject.ClickYesDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);



	}

	@Test(priority = 3)
	public void ExistingSubAccountTest() throws InterruptedException {
		timer = 3000;

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		//TestExistingSubAccount
		HomePageObject homePageObject = new HomePageObject(driver);
		SubAccountPageObject SubAccountPageObject = new SubAccountPageObject(driver);
        //CardsPageObject CardsPageObject= new CardsPageObject(driver);


        homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.EnterEmail("emelia+2@flutterwavego.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickNewAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountName();
		SubAccountPageObject.ClearSubAccountName();
		SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

		SubAccountPageObject.ClickSubAccountEmail();
		SubAccountPageObject.ClearSubAccountEmail();
		SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

		SubAccountPageObject.ClickSubAccountCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickCountryNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickBankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccountNumberTab();
		SubAccountPageObject.ClearAccountNumberTab();
		SubAccountPageObject.EnterAccountNumber("0690000034");

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatPaymentShare();
		SubAccountPageObject.ClearFlatPaymentShare();
		SubAccountPageObject.EnterFlatPaymentShare("50");

		SubAccountPageObject.ClickCreateSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

        SubAccountPageObject.ClickOverview();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickSubAccountButton();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickNewAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountName();
		SubAccountPageObject.ClearSubAccountName();
		SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

		SubAccountPageObject.ClickSubAccountEmail();
		SubAccountPageObject.ClearSubAccountEmail();
		SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

		SubAccountPageObject.ClickSubAccountCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickCountryNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickBankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccountNumberTab();
		SubAccountPageObject.ClearAccountNumberTab();
		SubAccountPageObject.EnterAccountNumber("0690000034");

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatPaymentShare();
		SubAccountPageObject.ClearFlatPaymentShare();
		SubAccountPageObject.EnterFlatPaymentShare("50");

		SubAccountPageObject.ClickCreateSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ExistingSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickCancelBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.MouseOver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);


		SubAccountPageObject.ClickYesDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);




	}

    @Test(priority = 4)
    public void SubAccountTestInvalidAccount() throws InterruptedException {
        timer = 3000;

        NavigateToURL startWebsite = new NavigateToURL(driver);

        startWebsite.launchURL();

        HomePageObject homePageObject = new HomePageObject(driver);
        SubAccountPageObject SubAccountPageObject = new SubAccountPageObject(driver);

        homePageObject.ClickEmail();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        homePageObject.ClearEmail();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        homePageObject.EnterEmail("emelia+2@flutterwavego.com");

        homePageObject.ClickPassword();

        homePageObject.ClearPassword();

        homePageObject.EnterPassword("Blonde77@1");

        homePageObject.ClickLogin();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

		SubAccountPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);


        homePageObject.TestModeMessageIsReturned();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickSubAccountButton();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickNewAccountButton();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickSubAccountName();
        SubAccountPageObject.ClearSubAccountName();
        SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

        SubAccountPageObject.ClickSubAccountEmail();
        SubAccountPageObject.ClearSubAccountEmail();
        SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

        SubAccountPageObject.ClickSubAccountCountry();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickCountryNG();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickBankName();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickAccessBank();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickAccountNumberTab();
        SubAccountPageObject.ClearAccountNumberTab();
        SubAccountPageObject.EnterAccountNumber("06900000");

        SubAccountPageObject.ScrollDownPage();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickSplitType();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickFlatSplitType();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.ClickFlatPaymentShare();
        SubAccountPageObject.ClearFlatPaymentShare();
        SubAccountPageObject.EnterFlatPaymentShare("50");

        SubAccountPageObject.ClickCreateSubAccount();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);

        SubAccountPageObject.InvalidAccountNumber();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(timer);


    }

	@Test(priority = 5)
	public void UpdateSubAccountTest() throws InterruptedException {
		timer = 3000;

		NavigateToURL startWebsite = new NavigateToURL(driver);

		startWebsite.launchURL();

		HomePageObject homePageObject = new HomePageObject(driver);
		SubAccountPageObject SubAccountPageObject = new SubAccountPageObject(driver);

		homePageObject.ClickEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.ClearEmail();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		homePageObject.EnterEmail("emelia+2@flutterwavego.com");

		homePageObject.ClickPassword();

		homePageObject.ClearPassword();

		homePageObject.EnterPassword("Blonde77@1");

		homePageObject.ClickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);


		SubAccountPageObject.ClickContinueToOldDashboard();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
		Thread.sleep(timer);

		homePageObject.TestModeMessageIsReturned();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickNewAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSubAccountName();
		SubAccountPageObject.ClearSubAccountName();
		SubAccountPageObject.EnterSubAccountName("Emelia Sunday");

		SubAccountPageObject.ClickSubAccountEmail();
		SubAccountPageObject.ClearSubAccountEmail();
		SubAccountPageObject.EnterSubAccountEmail("semelia25@gmail.com");

		SubAccountPageObject.ClickSubAccountCountry();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickCountryNG();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickBankName();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccessBank();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAccountNumberTab();
		SubAccountPageObject.ClearAccountNumberTab();
		SubAccountPageObject.EnterAccountNumber("0690000034");

		SubAccountPageObject.ScrollDownPage();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatSplitType();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickFlatPaymentShare();
		SubAccountPageObject.ClearFlatPaymentShare();
		SubAccountPageObject.EnterFlatPaymentShare("50");

		SubAccountPageObject.ClickCreateSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		driver.navigate().refresh();

		SubAccountPageObject.MouseOver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickUpdateButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickNewSubAccountName();
		SubAccountPageObject.ClearNewSubAccountName();
		SubAccountPageObject.EnterNewSubAccountName("Edet Sunday");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickUpdateSubAccountButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.MouseOver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickYesDeleteSubAccount();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickAvatar();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);

		SubAccountPageObject.ClickSignOut();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(timer);




	}





		@AfterTest

	public void TearDown() {
		driver.close();
		driver.quit();
		System.out.print("Test Page Passed");
	}

}






