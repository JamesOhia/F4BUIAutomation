package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class PaymentLinksPageObject {

	//Click on Payment Link Tab
	private By clickPaymentTab = By.xpath("//span[contains(text(),'Payment Links')]");

	//Create Payment Links SingleCharge
	private By createPaymentLink = By.xpath("//span[contains(text(),'Create Payment Link')]");
	private By singleChargeOption = By.xpath("//div[contains(text(),'Single charge allows you create payment links for ')]");
	private By enterPaymentName = By.xpath("//input[@id='pageName']");
	private By noNamePaymentLink = By.xpath("//span[contains(text(),'Enter Payment Link Name. Field cannot be empty')]");
	private By noDescriptionPaymentLink = By.xpath("//span[contains(text(),'Enter Description. Field cannot be empty')]");
	private By paymentLinkCreated = By.xpath("//div[contains(text(),'Payment Link was created successfully')]");
	private By countryCode = By.xpath("//select[@class = \"select__input select__input--paymentlinks\"]");
	private By selectNGN = By.xpath("(//option[contains(text(), \"NGN\")])[1]");
	private By enterAmount = By.xpath("(//input[@class = \"v-money form__input form__input--paymentlinks\"])");
	private By enterDescription = By.xpath("(//textarea[@class = \"form__input form__input__paymentlinksinput\"])");
	private By showMoreOptions = By.xpath("//div[@class = \"link link__paymentlinks textCenter\"]");
	private By customUrl = By.xpath("//input[@placeholder = \"Your url\"]");
	private By selectCurrency = By.xpath("//div[contains(text(),\"Select Currencies\")]");
	private By selectCAD = By.xpath("(//label[@class = \"checkbox__label\"])[8]");
	private By enterRedirectLink = By.xpath("(//input[@placeholder = \"https://google.com\"])[1]");
	private By enterFieldName = By.xpath("(//input[@class = \"input-field\"])");
	private By createLink = By.xpath("//button[contains(text(),'Create Link')]");
	private By linkCreated = By.xpath("//div[contains(text(),'Payment Link was created successfully')]");
	private By copyLink = By.xpath("'btn btn--primary btn--compact btn--copy'])[2]");
	private By deleteLink = By.xpath("(//button[@class ='btn btn--danger btn--compact btn-delete-link'])[1]");
	private By confirmDelete = By.xpath("//button[contains(text(),'Yes,delete payment link')]");
	//(//button[@class ="btn btn--danger btn--compact btn-delete-link"])[1]
	//(//button[@class = 'btn btn--primary btn--compact btn--copy'])[4]

	private By paymentLinkDataClicked = By.xpath("//div[contains(text(),'NGN 0')]");
	private By editPaymentLink = By.xpath("//button[contains(text(),'Edit')]");
	private By saveEditedPaymentLink = By.xpath("//button[contains(text(),'Save')]");
	private By waitPaymentLinkUpdated = By.xpath("//div[contains(text(),'Some information about this payment link')]");
	private By deactivatePaymentLink = By.xpath("//button[contains(text(),'Deactivate link')]");
	private By paymentLinkDeactivated = By.xpath("//div[contains(text(),'Payment Link Deactivated Successfully')]");
	private By deleteInsidePaymentButton = By.xpath("//button[contains(text(),'Delete')]");
	private By confirmDeleteInsidePaymentButton = By.xpath("//button[contains(text(),'Yes,delete payment link')]");
	private By paymentLinkDeleted = By.xpath("//div[contains(text(),'Payment Link Deleted Successfully')]");

	//Subscription Link
	private By subscriptionLinkOption = By.xpath("//div[contains(text(),'Create links where your customers can subscribe to')]");
	private By intervalClick = By.xpath("//input[@id='pageName']");
	private By intervalSelect = By.xpath("//input[@id='pageName']");
	private By numberCharge = By.xpath("//input[@id='pageName']");

	//Donation Page
	private By donationLinkOption = By.xpath("//div[contains(text(),'Create really simple links where your customers ca')]");
	private By pageTitle = By.xpath("(//input[@class = \"form__input form__input__paymentlinksinput\"])[1]");
	private By donationWebsite = By.xpath("(//input[@placeholder = \"https://google.com\"])[1]");
	private By donationPhoneNumber = By.xpath("(//input[@placeholder = \"08001234567\"])[1]");
	private By createPage = By.xpath("(//button[contains(text(),'Create Page')])[1]");
	private By pageCreated = By.xpath("//div[contains(text(),'Donation Page was created successfully')]");
	private By viewLink = By.xpath("(//a[contains(text(),\"View Link\")])");
	private By noNameDonationPage = By.xpath("(//span[contains(text(),'Enter Page Title. Field cannot be empty')])[1]");
	private By noDescriptionDonationPage = By.xpath("//span[contains(text(),'Enter Page Description. Field cannot be empty')]");
	private By paymentPageEdited = By.xpath("//div[contains(text(),'Payment Link was edited successfully')]");
	private By waitDonationLinkCreated = By.xpath("//div[contains(text(),'Page Name')]");

	private WebDriver driver;

	public PaymentLinksPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ScrollUp(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, -500)");
		System.out.println("Scrolled Page Up");
	}

	public void ScrollDown(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, 500)");
		System.out.println("Scrolled Page Down");
	}

	public void NavigateDown() {
		EventFiringWebDriver eventFiringWebDriver = new EventFiringWebDriver(driver);//Create the object
		//Execute the scrolling down script using css selector element
		eventFiringWebDriver.executeScript("document.querySelector('body.nprogress-container:nth-child(2) div:nth-child(1) div.positionRelative div.padTop--50 div:nth-child(3) > nav.nav.nav--sidebar.nav--sidebar-bannerPresent:nth-child(2)').scrollTop = 400");
		System.out.println("Scrolled Inner Scroll down");
	}

	public void ClickPaymentLinkTab() {

		try{
			driver.findElement(clickPaymentTab).click();

			System.out.println("Payment Link Tab was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CreatePaymentLink() {

		try{
			driver.findElement(createPaymentLink).click();

			System.out.println("Create Payment Link was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleCharge() {

		try{
			driver.findElement(singleChargeOption).click();

			System.out.println("Single Charge Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoNameErrorPaymentLink() {

		try{
			driver.findElement(noNamePaymentLink).isDisplayed();

			System.out.println("Enter Payment Link Name Field cannot be empty Error Message is displayed. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearPaymentName() {

		try{
			driver.findElement(enterPaymentName).clear();

			System.out.println("Payment Link Name was cleared");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPaymentName(String text) {

		try{
			driver.findElement(enterPaymentName).sendKeys(text);

			System.out.println("Payment Link Name was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoDescriptionPaymentLink() {

		try{
			driver.findElement(noDescriptionPaymentLink).isDisplayed();

			System.out.println("Enter Description. Field cannot be empty Error Message is displayed. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentLinkCreated() {

		try{
			driver.findElement(paymentLinkCreated).isDisplayed();

			System.out.println("Payment Link was created successfully. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentLinkDataClicked() {

		try{
			driver.findElement(paymentLinkDataClicked).click();

			System.out.println("Single Payment Link Created Data is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EditPaymentLink() {

		try{
			driver.findElement(editPaymentLink).click();

			System.out.println("Edit Payment Link Button is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SaveEditedPaymentLink() {

		try{
			driver.findElement(saveEditedPaymentLink).click();

			System.out.println("Save Payment Link Button is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitPaymentLinkUpdated() {

		try{
			driver.findElement(waitPaymentLinkUpdated).click();

			System.out.println("Waiting for Payment link to be Updated ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeactivatePaymentLink() {

		try{
			driver.findElement(deactivatePaymentLink).click();

			System.out.println("Deactivate Payment Link Button is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentLinkDeactivated() {

		try{
			driver.findElement(paymentLinkDeactivated).isDisplayed();

			System.out.println("Payment Link is Deactivated. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeleteInsidePaymentButton() {

		try{
			driver.findElement(deleteInsidePaymentButton).click();

			System.out.println("Payment Link Delete Inside Button is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ConfirmDeleteInsidePaymentButton() {

		try{
			driver.findElement(confirmDeleteInsidePaymentButton).click();

			System.out.println("Confirm Payment Link Delete Inside Button is clicked. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentLinkDeleted() {

		try{
			driver.findElement(paymentLinkDeleted).isDisplayed();

			System.out.println("Payment Link Button is deleted. ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCountryCode() {

		try{
			driver.findElement(countryCode).click();

			System.out.println("Country Code Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectNGN() {

		try{
			driver.findElement(selectNGN).click();

			System.out.println("NGN Country Code was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmount(String text) {

		try{
			driver.findElement(enterAmount).sendKeys(text);

			System.out.println("Amount was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDescription(String text) {

		try{
			driver.findElement(enterDescription).sendKeys(text);

			System.out.println("Description was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickMoreOptions() {

		try{
			driver.findElement(showMoreOptions).click();

			System.out.println("Show More Options was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterCustomURL(String text) {

		try{
			driver.findElement(customUrl).sendKeys(text);

			System.out.println("Custom URL was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrencies() {

		try{
			driver.findElement(selectCurrency).click();

			System.out.println("Select Currencies was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectCAD() {

		try{
			driver.findElement(selectCAD).click();

			System.out.println("CAD Currency was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterRedirectLink(String text) {

		try{
			driver.findElement(enterRedirectLink).sendKeys(text);

			System.out.println("Redirection Payment Link was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterFieldName(String text) {

		try{
			driver.findElement(enterFieldName).sendKeys(text);

			System.out.println("Field Name was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCreateLink() {

		try{
			driver.findElement(createLink).click();

			System.out.println("Create Link Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void LinkCreatedDisplayed() {

		try{
			driver.findElement(linkCreated).isDisplayed();

			System.out.println("Success Message for Payment Link Creation is displayed");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCopyLink() {

		try{
			driver.findElement(copyLink).click();

			System.out.println("Link was copied");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDeleteLink() {

		try{
			driver.findElement(deleteLink).click();

			System.out.println("Delete Link Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ConfirmDelete() {

		try{
			driver.findElement(confirmDelete).click();

			System.out.println("Link was deleted");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//SubscriptionLink
	public void ClickSubscriptionLink() {

		try{
			driver.findElement(subscriptionLinkOption).click();

			System.out.println("Subscription Link Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickInterval() {

		try{
			driver.findElement(intervalClick).click();

			System.out.println("Interval Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectInterval() {

		try{
			driver.findElement(intervalSelect).click();

			System.out.println("Interval was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterChargeNumber(String text) {

		try{
			driver.findElement(numberCharge).sendKeys(text);

			System.out.println("The Number of times to charge a subscriber was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Donation Page
	public void ClickDonationPage() {

		try{
			driver.findElement(donationLinkOption).click();

			System.out.println("Donation Page Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoNameDonationPage() {

		try{
			driver.findElement(noNameDonationPage).isDisplayed();

			System.out.println("Enter Page Title. Field cannot be empty is displayed");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoDescriptionDonationPage() {

		try{
			driver.findElement(noDescriptionDonationPage).isDisplayed();

			System.out.println("Enter Page Description. Field cannot be empty error message is displayed");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentPageEdited() {

		try{
			driver.findElement(paymentPageEdited).isDisplayed();

			System.out.println("Payment Link/Page was edited successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPageTitle(String text) {

		try{
			driver.findElement(pageTitle).sendKeys(text);

			System.out.println("Page Title was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDonationWebsite(String text) {

		try{
			driver.findElement(donationWebsite).sendKeys(text);

			System.out.println("Donation Website was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDonationPhoneNumber(String text) {

		try{
			driver.findElement(donationPhoneNumber).sendKeys(text);

			System.out.println("Donation Phone Number was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCreatePage() {

		try{
			driver.findElement(createPage).click();

			System.out.println("Create Page Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PageCreated() {

		try{
			driver.findElement(pageCreated).isDisplayed();

			System.out.println("Donation Page was Created");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickViewLink() {

		try{
			driver.findElement(viewLink).click();

			System.out.println("View Link Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitDonationLinkCreated() {

		try{
			driver.findElement(waitDonationLinkCreated).isDisplayed();

			System.out.println("Waiting for the donation success message to disappear");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
}







