package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


public class SubAccountPageObject {

	private By subAccounttab 	 	 = By.xpath("//span[contains(text(),'Subaccounts')]");
	private By newAccount			 = By.xpath("//span[contains(text(),'New Subaccount')]");
	private By subAccountName 		 = By.xpath("(//input[@type = \"text\" and @class=\"form__input\"])[4]");
	private By subAccountEmail       = By.xpath("(//input[@type = \"text\" and @class=\"form__input\"])[5]");
	private By subAccountCountry     = By.xpath("//select [@class = 'select__input' and @required = 'required'] ");
	private By countryNG			 = By.xpath("(//option[@value='NG' ])[1]");
	private By countryGH 			 = By.xpath("(//option[@value='GH' ])[1]");
	private By bankName 		     = By.xpath("(//select[@class='select__input text-uppercase' ])[1]");
	private By accessBank 			 = By.xpath("(//option[@value='044' ])[1]");
	private By accessBankGH 		 = By.xpath("(//option[contains(text(),'Access Bank (Ghana) PLC')]) [1]");
	private By accessBankGHBranchTab = By.xpath("(//select[@class='select__input text-uppercase' ])[2]");
	private By accessBankGHBranch    = By.xpath("(//option[@value='18120517SM' ])[1]");
	private By accountNumberTab      = By.xpath("(//input[@type = \"text\" and @class=\"form__input\"])[6]");
	private By splittype             = By.xpath("(//select[@class='select__input'])[2]");
	private By splittypeFlat 		 = By.xpath("//option[@value='flat']");
	private By splittypePercentage   = By.xpath("//option[@value='percentage' and @ xpath='1']");
	private By flatPaymentshare 	 = By.xpath("(//input[@type = \"number\" and @class=\"form__input\"])[1]");
	private By createSubAccount		 = By.xpath("//button[contains(text(),'Create New Subaccount')]");
	private By deleteTab 			 = By.xpath("//button[contains(text(),'Delete')]");
	private By deleteConfirm         = By.xpath("//button[contains(text(),'Yes, delete subaccount')]");
	private By deletemessage         = By.xpath("div[contains(text(),'Subaccount deleted successfully')]");
	private By invalidAccount 		 = By.xpath("//div[contains(text(),\"Sorry we couldn't verify your account number kindly pass a valid account number.\")]");
	private By existingSubAccount    = By.xpath("//div[contains(text(),'A subaccount with the account number and bank alre')]");
	private By overview 			 = By.xpath("\t//span[contains(text(),'Overview')]\n");
	private By updateButton          = By.xpath("(//button[contains (text() , 'Update')])[1]");
	private By updatePercentage		 = By.xpath("//option[@value='percentage' and @xpath='1']");
	private By updateSubAccountName  = By.xpath("(//input[@type = \"text\" and @class=\"form__input\"])[7]");
	private By updateSubAccount      = By.xpath("//button[contains(text(),'Update Subaccount')]");
	private By updateMessage         = By.xpath("//div[contains(text(),'Subaccount successfully edited')]");
	private By avatar                = By.xpath("//img[@class='avatar__icon imgCircle' ]");
	private By signOut               = By.xpath("//div[contains(text(),'Sign out')]");
	private By continueToOldDashboard = By.xpath("//button[contains(text(),'Continue to the old')]");
	private By cancelBtn = By.xpath("(//button[contains(text(),'Cancel')]) [3]\n");



	private WebDriver driver;


	public SubAccountPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickSubAccountButton() {
		try {
			driver.findElement(subAccounttab).click();
			System.out.println("SubAccount button Menu was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	//Trying to use the mouse actions
	public void MouseOver() {

		WebElement mouseOver = driver.findElement(By.xpath("//div[contains(text(),'Emelia Sunday')]"));
		Actions action = new Actions(driver);
		action.moveToElement(mouseOver).perform();

	}

	public void ClickCancelBtn() {
		try {
			driver.findElement(cancelBtn).click();
			System.out.println("The Cancel button was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickContinueToOldDashboard() {
		try{
			driver.findElement(continueToOldDashboard).click();
			System.out.println("The continue to old dashboard lable link was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewAccountButton() {
		try {
			driver.findElement(newAccount).click();
			System.out.println("New Account button Menu was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickSubAccountName() {
		try {
			driver.findElement(subAccountName).click();
			System.out.println("SubAccount Name field was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearSubAccountName() {
		try {
			driver.findElement(subAccountName).click();
			System.out.println("SubAccount Name field was cleared");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterSubAccountName(String text) {
		try {
			driver.findElement(subAccountName).sendKeys(text);
			System.out.println("SubAccount Name field was entered");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClickSubAccountEmail() {
		try {
			driver.findElement(subAccountEmail).click();
			System.out.println("SubAccount Email field was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearSubAccountEmail() {
		try {
			driver.findElement(subAccountEmail).click();
			System.out.println("SubAccount Email field was cleared");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterSubAccountEmail(String text) {
		try {
			driver.findElement(subAccountEmail).sendKeys(text);
			System.out.println("SubAccount Email was entered");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickSubAccountCountry() {
		try {
			driver.findElement(subAccountCountry).click();
			System.out.println("SubAccount country was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCountryNG() {
		try {
			driver.findElement(countryNG).click();
			System.out.println("NG was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCountryGH() {
		try {
			driver.findElement(countryGH).click();
			System.out.println("GH was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	public void ClickBankName() {
		try {
			driver.findElement(bankName).click();
			System.out.println("Bank Name option was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAccessBank() {
		try {
			driver.findElement(accessBank).click();
			System.out.println("Access Bank was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAccessBankGH() {
		try {
			driver.findElement(accessBankGH).click();
			System.out.println("Access Bank GH was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAccessBankGHBranch() {
		try {
			driver.findElement(accessBankGHBranchTab).click();
			System.out.println("Access BankGH Branch tab was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAccessBankGHPLC() {
		try {
			driver.findElement(accessBankGHBranch).click();
			System.out.println("Access Bank GH PLC was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClickAccountNumberTab() {
		try {
			driver.findElement(accountNumberTab).click();
			System.out.println("Account Number field was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearAccountNumberTab() {
		try {
			driver.findElement(accountNumberTab).click();
			System.out.println("Account Number field was cleared");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterAccountNumber(String text) {
		try {
			driver.findElement(accountNumberTab).sendKeys(text);
			System.out.println("Account Number was entered");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickSplitType() {
		try {
			driver.findElement(splittype).click();
			System.out.println("Split Type option was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickFlatSplitType() {
		try {
			driver.findElement(splittypeFlat).click();
			System.out.println("Flat Split Type was selected");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickFlatPaymentShare() {
		try {
			driver.findElement(flatPaymentshare).click();
			System.out.println("Flat Payment Share field was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearFlatPaymentShare() {
		try {
			driver.findElement(flatPaymentshare).click();
			System.out.println("Flat Payment Share field was cleared");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterFlatPaymentShare(String text) {
		try {
			driver.findElement(flatPaymentshare).sendKeys(text);
			System.out.println("Flat Payment Amount was entered");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ScrollDownPage() {
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, +1000)");
	}

	public void ScrollUpPage() {
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, +1000)");
	}

	public void ClickCreateSubAccount() {
		try {
			driver.findElement(createSubAccount).click();
			System.out.println("SubAccount was created");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickDeleteSubAccount() {
		try {
			driver.findElement(deleteTab).click();
			System.out.println("SubAccount Tab was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickYesDeleteSubAccount() {
		try {
			driver.findElement(deleteConfirm).click();
			System.out.println("Delete Success message is displayed to the user");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ExistingSubAccount() {
		try {
			driver.findElement(existingSubAccount).isDisplayed();
			System.out.println("A subaccount with the account number and bank already exists");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidAccountNumber() {
		try {
			driver.findElement(invalidAccount).isDisplayed();
			System.out.println("Sorry we couldn't verify your account number kindly pass a valid account number");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickOverview() {
		try {
			driver.findElement(overview).click();
			System.out.println("Overview was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	public void ClickUpdateButton() {
		try {
			driver.findElement(updateButton).click();
			System.out.println("Update SubAccount Button was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	public void ClickUpdateSubAccountButton() {
		try {
			driver.findElement(updateSubAccount).click();
			System.out.println("Update success message was displayed to the user");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	public void ClickNewSubAccountName() {
		try {
			driver.findElement(updateSubAccountName).click();
			System.out.println("SubAccount Name field was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearNewSubAccountName() {
		try {
			driver.findElement(updateSubAccountName).click();
			System.out.println("SubAccount Name field was cleared");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterNewSubAccountName(String text) {
		try {
			driver.findElement(updateSubAccountName).sendKeys(text);
			System.out.println("SubAccount Name field was entered");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	public void ClickAvatar() {
		try {
			driver.findElement(avatar).click();
			System.out.println("Avatar button was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

public void ClickSignOut() {
	try {
		driver.findElement(signOut).click();
		System.out.println("Sign out button was clicked");
	} catch (Exception e) {
		throw new RuntimeException(e.getMessage());
	}

}


}










