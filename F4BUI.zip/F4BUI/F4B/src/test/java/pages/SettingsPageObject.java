package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class SettingsPageObject {

	//Click on Settings Tab
	private By settingsTab = By.xpath("(//span[contains(text(),\"Settings\")])[1]");

	//General
	private By general = By.xpath("//div[contains(text(),'General')]");
	private By enterNumber = By.xpath("(//input[@class = \"form__input\"])[8]");
	private By changePassword = By.xpath("(//button[@class = \"btn btn--default\"])[3]");
	private By oldPassword = By.xpath("(//input[@type =\"password\"])[1]");
	private By newPassword = By.xpath("//input[@id='password']");
	private By confirmPassword = By.xpath("(//input[@class =\"form__input\"])[17]");
	private By clickPassword = By.xpath("(//button[contains(text(),'Change password')])[2]");
	private By cancelPassword = By.xpath("(//button[@aria-label = \"Close\"])[6]");

	//Bank Accounts
	private By bankAccounts = By.xpath("//div[contains(text(),'Bank Accounts')]");
	private By addNewBank = By.xpath("//span[contains(text(),'Add New Bank')]");
	private By country = By.xpath("(//select[@class = \"select__input\"])[1]");
	private By nigeria = By.xpath("(//option[@value = \"NG\"])[1]");
	private By bankName = By.xpath("(//select[@class = \"select__input\"])[3]");
	private By accessBank = By.xpath("(//option[contains(text(),'Access Bank')])[1]");
	private By accountNumber = By.xpath("(//input[@class = \"form__input\"])[5]");
	private By primaryAccount = By.xpath("(//label[@for = 'primaryaccountedit'])[1]");
	private By currency = By.xpath("(//select[@class = \"select__input\"])[2]");
	private By ngn = By.xpath("(//option[@value = \"NGN\"])");
	private By addBank = By.xpath("//button[contains(text(),'Add new bank')]");
	private By bankAdded = By.xpath("//div[contains(text(),'Account has been added successfully')]");
	private By editBank = By.xpath("(//button[contains(text(),'Edit')])[2]");
	private By deleteBank = By.xpath("//button[contains(text(),'Delete')]");
	private By bankDeleted = By.xpath("//div[contains(text(),'Account has been deleted successfully')]");
	private By bankNameShow = By.xpath("//div[contains(text(),'Bank Name')]");
	private By accountShow = By.xpath("//div[contains(text(),'Account Number')]");

	//Users
	private By usersTab = By.xpath("(//div[contains(text(),'Users')])[1]");
	private By inviteUser = By.xpath("//span[contains(text(),'Invite User')]");
	private By emailUser = By.xpath("(//input[@type = \"email\"])[2]");
	private By selectRole = By.xpath("(//select[@class = \"select__input\"])[1]");
	private By selectAdmin = By.xpath("(//option[contains(text(),  'Admin')])[1]");
	private By clickInviteUser = By.xpath("//button[contains(text(),'Invite User')]");
	private By cancelInvite = By.xpath("(//button[@class = \"btn btn--default\"])[3]");
	private By removeUser = By.xpath("(//button[@class = \"btn btn--danger btn--compact\"])");
	private By cancelUser = By.xpath("(//button[@class = \"btn btn--default\"])[5]");
	private By waitingUser1 = By.xpath("//div[contains(text(),'Name')]");
	private By waitingUser2 = By.xpath("//div[contains(text(),'Email Address')]");

	//API Webhook and Settings
	private By apiTab = By.xpath("(//div[contains(text(),'API')])[1]");
	private By copyPublic = By.xpath("(//button[contains(text(),'Copy key')])[1]");
	private By copySecret = By.xpath("(//button[contains(text(),'Copy key')])[2]");
	private By copyEncryption = By.xpath("(//button[contains(text(),'Copy key')])[3]");

	//WebHooks
	private By webhooksTab = By.xpath("//div[contains(text(),'Webhooks')]");
	private By enterUrl = By.xpath("(//input[@type = \"url\"])[1]");
	private By enterHash = By.xpath("(//input[@class = \"form__input\"])[6]");

	//Account Settings
	private By accountTab = By.xpath("(//span[contains(text(), 'Settings')])[2]");
	private By selectCustomerPay = By.xpath("//label[contains(text(),'Make customers pay the transaction fees')]");
	private By selectMePay = By.xpath("//label[contains(text(),'Charge me for the transaction fees')]");
	private By saveSettings = By.xpath("//button[contains(text(),'Save')]");
	private By transactionEmail = By.xpath("//label[contains(text(),'Email me for every transaction')]");
	private By transactionCustomers = By.xpath("//label[contains(text(),'Email customers for every transaction')]");
	private By paymentMethod = By.xpath("//label[contains(text(),'Enable Dashboard Payment Options')]");
	private By waitingSettings = By.xpath("//div[contains(text(),'Preferences')]");



	private WebDriver driver;

	public SettingsPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ScrollUp(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, -500)");
		System.out.println("Scrolled Page Up");
	}

	public void ScrollDown(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, 500)");
		System.out.println("Scrolled Page Down");
	}

	public void NavigateDown() {
		EventFiringWebDriver eventFiringWebDriver = new EventFiringWebDriver(driver);//Create the object
		//Execute the scrolling down script using css selector element
		eventFiringWebDriver.executeScript("document.querySelector('body.nprogress-container:nth-child(2) div:nth-child(1) div.positionRelative div.padTop--50 div:nth-child(3) > nav.nav.nav--sidebar.nav--sidebar-bannerPresent:nth-child(2)').scrollTop = 400");
		System.out.println("Scrolled Inner Scroll down");
	}

	public void ClickSettingsTab() {

		try{
			driver.findElement(settingsTab).click();

			System.out.println("Settings Tab was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//General
	public void ClickGeneral() {

		try{
			driver.findElement(general).click();

			System.out.println("General was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterNumber(String Text) {

		try{
			driver.findElement(enterNumber).sendKeys();

			System.out.println("Phone Number was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ChangePassword() {

		try{
			driver.findElement(changePassword).click();

			System.out.println("Change Password Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterOldPassword(String text) {

		try{
			driver.findElement(oldPassword).sendKeys(text);

			System.out.println("Old Password was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterNewPassword(String text) {

		try{
			driver.findElement(newPassword).sendKeys(text);

			System.out.println("New Password was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterConfirmPassword(String text) {

		try{
			driver.findElement(confirmPassword).sendKeys(text);

			System.out.println("Confirm Password was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CancelPassword() {

		try{
			driver.findElement(cancelPassword).click();

			System.out.println("Cancel Password was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Bank Accounts

	public void BankAccounts() {

		try{
			driver.findElement(bankAccounts).click();

			System.out.println("Bank Accounts was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AddNewBank() {

		try{
			driver.findElement(addNewBank).click();

			System.out.println("Add New Bank Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCountry() {

		try{
			driver.findElement(country).click();

			System.out.println("Currency drop down was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectNigeria() {

		try{
			driver.findElement(nigeria).click();

			System.out.println("Nigeria country was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BankName() {

		try{
			driver.findElement(bankName).click();

			System.out.println("Bank Name was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AccessBank() {

		try{
			driver.findElement(accessBank).click();

			System.out.println("Access Bank was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAccountNumber(String text) {

		try{
			driver.findElement(accountNumber).sendKeys(text);

			System.out.println("Account Number was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPrimaryAccount() {

		try{
			driver.findElement(primaryAccount).click();

			System.out.println("Make this my primary bank account was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrency() {

		try{
			driver.findElement(currency).click();

			System.out.println("Currency drop down menu was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNGN() {

		try{
			driver.findElement(nigeria).click();

			System.out.println("NGN currency was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AddBank() {

		try{
			driver.findElement(addBank).click();

			System.out.println("Add Bank Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BankAdded() {

		try{
			driver.findElement(bankAdded).isDisplayed();

			System.out.println("Bank was added");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EditBank() {

		try{
			driver.findElement(editBank).click();

			System.out.println("Edit Bank Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeleteBank() {

		try{
			driver.findElement(deleteBank).click();

			System.out.println("Delete Bank Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BankDeleted() {

		try{
			driver.findElement(bankDeleted).isDisplayed();

			System.out.println("Bank was deleted");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingDelete1() {

		try{
			driver.findElement(bankNameShow).isDisplayed();

			System.out.println("Waiting for the delete notification to disappear");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingDelete2() {

		try{
			driver.findElement(bankNameShow).isDisplayed();


		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Users
	public void UsersTab() {

		try{
			driver.findElement(usersTab).click();

			System.out.println("Users Tab was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InviteUser() {

		try{
			driver.findElement(inviteUser).click();

			System.out.println("Invite User Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterEmailUser(String Text) {

		try{
			driver.findElement(emailUser).sendKeys(Text);

			System.out.println("User's Email was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectRole() {

		try{
			driver.findElement(selectRole).click();

			System.out.println("Select Role was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectAdmin() {

		try{
			driver.findElement(selectAdmin).click();

			System.out.println("Admin Role was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickInviteUser() {

		try{
			driver.findElement(clickInviteUser).click();

			System.out.println("Invite User Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CancelInvite() {

		try{
			driver.findElement(cancelInvite).click();

			System.out.println("Cancel User Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void RemoveUser() {

		try{
			driver.findElement(removeUser).click();

			System.out.println("Remove User Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CancelUser() {

		try{
			driver.findElement(cancelUser).click();

			System.out.println("Cancel button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingUser1() {

		try{
			driver.findElement(waitingUser1).click();

			System.out.println("Waiting for User notification");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingUser2() {

		try{
			driver.findElement(waitingUser1).click();

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
	//API

	public void ApiTab() {

		try{
			driver.findElement(apiTab).click();

			System.out.println("API Tab Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CopyPublic() {

		try{
			driver.findElement(copyPublic).click();

			System.out.println("Copy Public Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CopySecret() {

		try{
			driver.findElement(copySecret).click();

			System.out.println("Copy Secret Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CopyEncryption() {

		try{
			driver.findElement(copyEncryption).click();

			System.out.println("Copy Encryption Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//WebHooks
	public void WebHooksTab() {

		try{
			driver.findElement(webhooksTab).click();

			System.out.println("WebHook Tab was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
	public void EnterUrl(String text) {

		try{
			driver.findElement(enterUrl).sendKeys(text);

			System.out.println("URL was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterHash(String text) {

		try{
			driver.findElement(enterHash).sendKeys(text);

			System.out.println("Hash was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Account Settings
	public void AccountTab() {

		try{
			driver.findElement(accountTab).click();

			System.out.println("Account Tab was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectCustomerPay() {

		try{
			driver.findElement(selectCustomerPay).click();

			System.out.println("Make Customer pay the transaction was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectMePay() {

		try{
			driver.findElement(selectMePay).click();

			System.out.println("Charge me for the transaction fees was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransactionEmail() {

		try{
			driver.findElement(transactionEmail).click();

			System.out.println("Email me for every transaction was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransactionCustomers() {

		try{
			driver.findElement(transactionCustomers).click();

			System.out.println("Email customers for every transaction was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentMethod() {

		try{
			driver.findElement(paymentMethod).click();

			System.out.println("Enable DashBoard Payment Options was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SaveSettings() {

		try{
			driver.findElement(saveSettings).click();

			System.out.println("Save Settings was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingSettings() {

		try{
			driver.findElement(waitingSettings).isDisplayed();

			System.out.println("Waiting for account save notification to disappear");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


}







