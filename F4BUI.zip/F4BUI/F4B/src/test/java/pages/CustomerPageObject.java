package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.File;

public class CustomerPageObject {

	private By customersButton = By.xpath("//span[contains(text(),'Customers')]");
	private By customerHeader = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[1]/div[1]/div[1]");
	private By customerName = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/p[1]");
	private By customerInformation = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/p[1]");
	private By blacklistLabel = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[4]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]");
	private By blacklistModal = By.xpath("//div[contains(text(),'Blacklist customer')]");
	private By customerDownload = By.xpath("//span[contains(text(),'Download')]");
	private By blacklistModalCancelButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[8]/div[1]/div[1]/div[2]/form[1]/div[1]/button[1]");
	private By blacklistCustomer = By.xpath("//button[contains(text(),'Blacklist customer')]");
	private By blacklistDisplayMessage = By.xpath("//div[contains(text(),'Emelia is a blacklisted customer, Blacklisted cust')]");
	private By blacklistSuccessMessage = By.xpath("//div[contains(text(),'Customer was blacklisted successfully')]");
	private By whitelistLabel = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[5]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]");
	private By whitelistModal = By.xpath("//div[contains(text(),'Whitelist customer')]");
	private By whitelistModalXButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[10]/div[1]/div[1]/div[1]/button[1]/*[1]");
	private By whitelistModalCancelButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[10]/div[1]/div[1]/div[2]/form[1]/div[1]/button[1]");
	private By whitelistCustomer = By.xpath("//button[contains(text(),'Whitelist customer')]");
	private By whitelistSuccessMessage = By.xpath("//div[contains(text(),'Customer has been whitelisted successfully')]");
	private By showMoreCustomerInfo = By.xpath("//div[contains(text(),'Show More')]");
	private By customerTransaction = By.xpath("//div[contains(text(),'All Transactions')]");
	private By successfulLabel = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[5]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/span[1]");
	private By successfulTransaction = By.xpath("//div[contains(text(),'Payment from semelia23@gmail.com')]");
	private By editCustomer = By.xpath("//button[contains(text(),'Edit Customer')]");
	private By editCustomerInformation = By.xpath("//div[contains(text(),'Edit Customer Information')]");
	private By editCustomerName = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[10]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/input[1]");
	private By editCustomerEmail = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[10]/div[1]/div[1]/div[2]/form[1]/div[1]/div[2]/input[1]");
	private By editCustomerNumber = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[10]/div[1]/div[1]/div[2]/form[1]/div[1]/div[3]/div[1]/input[1]");
	private By editSaveChangesButton = By.xpath("//button[contains(text(),'Save Changes')]");
	private By editCustomerSuccessMessage = By.xpath("//div[contains(text(),'Customer has been edited successfully')]");
	private By customerBackButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[2]");
	private By newCustomer = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/button[1]/span[1]/*[1]");
	private By addCustomerModal = By.xpath("//div[contains(text(),'Add Customer')]");
	private By addCustomerXButton = By.xpath("//body[1]/div[1]/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/button[1]/svg[1]/ellipse[1]");
	private By addCustomerCancelButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[2]/div[2]/button[1]");
	private By addCustomerName = By.xpath("(//input[@type= \"text\" and @class=\"form__input\"])[4]");
	private By addCustomerEmail = By.xpath("(//input[@type= \"text\" and @class=\"form__input\"])[5]");
	private By addCustomerNumber = By.xpath("(//input [@type= 'text' and @class='borderless-form']) [2]");
	private By addCustomer = By.xpath("//button[contains(text(),'Add Customer')]");
	private By addCustomerSuccessMessage = By.xpath("//div[contains(text(),'Customer has been added successfully')]");
	private By downloadCustomer = By.xpath("//span[contains(text(),'Download')]");
	private By downloadCustomerSuccessMessage = By.xpath("//div[contains(text(),'Fetch Complete, Downloading...')]");
	private By blacklistHeader = By.xpath("//div[contains(text(),'Blacklist')]");
	private By downloadBlacklistedCustomers = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span[1]");
	private By downloadBlacklistedCustomersSuccessMessage = By.xpath("//div[contains(text(),'Fetching Download...')]");
	private By blacklistedEmailList = By.xpath("//p[contains(text(),'Email List')]");
	private By blacklistedEmailCustomers = By.xpath("//div[contains(text(),'1 Blacklisted Customer(s)')]");
	private By removeBlacklistedEmailCustomer = By.xpath("//button[contains(text(),'Remove')]");
	private By removeBlacklistedEmailCustomerSuccessful = By.xpath("//div[contains(text(),'Successfully whitelisted customer.')]");
	private By addBlacklistEmailCustomer = By.xpath("//button[contains(text(),'Add your first email')]");
	private By addSingleBlacklistEmail = By.xpath("//div[contains(text(),'Single Email address')]");
	private By singleBlacklistEmail = By.xpath("//input[@type = \"email\" and @placeholder =\"Enter customer email\"]");
	private By singleBlacklistEmail2 = By.xpath("//input[contains(text(),'Enter customer email')]");
	private By singleBlacklistEmailButton = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/button[2]");
	private By singleBlacklistEmailSuccessMessage = By.xpath("//div[contains(text(),'Blacklisting successful')]");
	private By singleBlacklistEmailDownload = By.xpath("//span[contains(text(),'Download')]");
	private By addEmailBlacklistButton = By.xpath("//button[contains(text(),'Add email to list')]");
	private By uploadMultipleBlacklistEmail = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]");
	private By chooseFileUpload = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]");
	private By chooseFileUploadLatest = By.xpath("//button[contains(text(),'Choose file')]");
	private By fileUpload = By.xpath ("bulk_blacklist_emails.csv");
	private By bulkEmailBlacklistButton = By.xpath ("//body/div[@id='app']/div[1]/div[1]/main[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/button[2]");
	private By downloadEmailBlacklistSample = By.xpath("//a[contains(text(),'Download a blacklist sample of Emails')]");
	private By cardPanBlacklist = By.xpath("//p[contains(text(),'Card PAN List')]");
	private By addCardPanBlacklist = By.xpath("//button[contains(text(),'Add your first card')]");
	private By addSingleCardPan = By.xpath("//div[contains(text(),'Single Card Pan')]");
	private By addSingleCardPanDetails1 = By.xpath(" //body/div[@id='app']/div[1]/div[1]/main[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/input[1]");
	private By addSingleCardPanDetails2 = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]");
	private By blacklistSingleCardPan = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/button[2]");
	private By cardPanBlacklistedSuccessMessage = By.xpath("//div[contains(text(),'Blacklisting successful')]");
	private By ipAddressBlacklist = By.xpath("//p[contains(text(),'IP address List')]");
	private By addIpAddressBlacklist = By.xpath("//button[contains(text(),'Add your first IP address')]");
	private By addSingleIpAddress = By.xpath("//div[contains(text(),'Single IP Address')]");
	private By singleIpAddressField = By.xpath("//input[@type = \"text\" and @placeholder =\"Enter IP Address\"]");
	private By blacklistIpAddress = By.xpath("//button[contains(text(),'Blacklist Ip')]");
	private By blacklistIpAddressSuccessMessage = By.xpath("//div[contains(text(),'Blacklisting successful')]");
	//private By whitelistLabel =By.xpath("");
	//private By whitelistLabel =By.xpath("");
	//private By whitelistLabel =By.xpath("");
	//private By whitelistLabel =By.xpath(""); */

	/*public void UploadFileButton() {
		try {
			File file = new File(“\\PATH\\FILENAME”);
			driver.findElement(ELEMENT).sendKeys(file.getAbsolutePath());
			System.out.println(“The File was uploaded");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}*/

	private WebDriver driver;

	public CustomerPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickCustomersButton() {

		try {
			driver.findElement(customersButton).click();

			System.out.println("customers Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewCustomer() {

		try {
			driver.findElement(newCustomer).click();

			System.out.println("Add new customer initiated");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewCustomerNameField() {

		try {
			driver.findElement(addCustomerName).click();

			System.out.println("New customer name field clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterNewCustomerName(String text) {

		try {
			driver.findElement(addCustomerName).sendKeys(text);

			System.out.println("Customer name was entered into the text field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewCustomerEmailField() {

		try {
			driver.findElement(addCustomerEmail).click();

			System.out.println("Customer Email field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterNewCustomerEmail(String text) {

		try {
			driver.findElement(addCustomerEmail).sendKeys(text);

			System.out.println("Customer Email was entered into the field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickNewCustomerNumberField() {

		try {
			driver.findElement(addCustomerNumber).click();

			System.out.println("Customer Phone number field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterNewCustomerNumber(String text) {

		try {
			driver.findElement(addCustomerNumber).sendKeys(text);

			System.out.println("Customer Phone number was entered into the field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAddCustomerButton() {

		try {
			driver.findElement(addCustomer).click();

			System.out.println("Add customer button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AddCustomerSuccessMessageIsDisplayed() {

		try {
			driver.findElement(addCustomerSuccessMessage).isDisplayed();

			System.out.println("Customer added success message is displayed to user");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCustomerDownload() {

		try {
			driver.findElement(customerDownload).click();

			System.out.println("Customer list downloaded successfully");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCustomerName() {

		try {
			driver.findElement(customerName).click();

			System.out.println("Customer name was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickEditCustomer() {

		try {
			driver.findElement(editCustomer).click();

			System.out.println("Edit Customer button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickEditCustomerName() {

		try {
			driver.findElement(editCustomerName).click();

			System.out.println("Customer name field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearCustomerName() {

		try {
			driver.findElement(editCustomerName).clear();

			System.out.println("Customer name field was Cleared");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterCustomerName(String text) {

		try {
			driver.findElement(editCustomerName).sendKeys(text);

			System.out.println("Customer edited name");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickEditCustomerEmail() {

		try {
			driver.findElement(editCustomerEmail).click();

			System.out.println("Customer Email field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClearCustomerEmail() {

		try {
			driver.findElement(editCustomerEmail).clear();

			System.out.println("Customer email field was Cleared");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterCustomerEmail(String text) {

		try {
			driver.findElement(editCustomerEmail).sendKeys(text);

			System.out.println("Customer edited email address");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickEditCustomerNumber() {

		try {
			driver.findElement(editCustomerNumber).click();

			System.out.println("Customer Number field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClearCustomerNumber() {

		try {
			driver.findElement(editCustomerNumber).clear();

			System.out.println("Customer number field was Cleared");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterCustomerNumber(String text) {

		try {
			driver.findElement(editCustomerNumber).sendKeys(text);

			System.out.println("Customer edited phone number");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickEditSaveButton() {

		try {
			driver.findElement(editSaveChangesButton).click();

			System.out.println("Save changes button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void CustomerEditedSuccessMessageIsDisplayed() {

		try {
			driver.findElement(editCustomerSuccessMessage).isDisplayed();

			System.out.println("Customer edited successfully is displayed to user");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickBlacklistLabel() {

		try {
			driver.findElement(blacklistLabel).click();

			System.out.println("Blacklist label was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBlacklistButton() {

		try {
			driver.findElement(blacklistCustomer).click();

			System.out.println("Blacklist customer button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickWhitelistLabel() {

		try {
			driver.findElement(whitelistLabel).click();

			System.out.println("Whitelist label was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickWhitelistButton() {

		try {
			driver.findElement(whitelistCustomer).click();

			System.out.println("Whitelist customer button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void BlacklistSuccessMessageIsDisplayed() {

		try {
			driver.findElement(blacklistSuccessMessage).isDisplayed();

			System.out.println("Customer blacklisted successfully");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void WhitelistSuccessMessageIsDisplayed() {

		try {
			driver.findElement(whitelistSuccessMessage).isDisplayed();

			System.out.println("Customer whitelisted successfully");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickBlacklistHeader() {

		try {
			driver.findElement(blacklistHeader).click();

			System.out.println("Blacklist header was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickBlacklistedEmailList() {

		try {
			driver.findElement(blacklistedEmailList).click();

			System.out.println("Blacklisted Email list was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickBlacklistedEmailCustomer() {

		try {
			driver.findElement(blacklistedEmailCustomers).click();

			System.out.println("Blacklisted Email Customer was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickRemoveBlacklistedEmailCustomer() {

		try {
			driver.findElement(removeBlacklistedEmailCustomer).click();

			System.out.println("Blacklisted Email Customer was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void BlacklistedEmailCustomerRemovedIsDisplayed() {

		try {
			driver.findElement(removeBlacklistedEmailCustomerSuccessful).isDisplayed();

			System.out.println("Blacklisted Email Customer was removed");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAddBlacklistEmailButton() {

		try {
			driver.findElement(addEmailBlacklistButton).click();

			System.out.println("Add New Blacklisted Email Customer was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAddBlacklistEmailCustomer() {

		try {
			driver.findElement(addBlacklistEmailCustomer).click();

			System.out.println("Add New Blacklisted Email Customer was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClickAddSingleBlacklistEmail() {

		try {
			driver.findElement(addSingleBlacklistEmail).click();

			System.out.println("Add Single Blacklist Email Customer was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClickSingleBlacklistEmail() {

		try {
			driver.findElement(singleBlacklistEmail).click();

			System.out.println("Single Blacklisted Email field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClearSingleBlacklistEmail() {

		try {
			driver.findElement(singleBlacklistEmail).clear();

			System.out.println("Single Blacklisted Email field was Cleared");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterSingleBlacklistEmail(String text) {

		try {
			driver.findElement(singleBlacklistEmail).sendKeys(text);

			System.out.println("Email was entered into Single Blacklisted Email field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickSingleBlacklistEmailButton() {

		try {
			driver.findElement(singleBlacklistEmailButton).click();

			System.out.println("Single Blacklisted Email button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void SingleBlacklistEmailSuccessMessageIsDisplayed() {

		try {
			driver.findElement(singleBlacklistEmailSuccessMessage).isDisplayed();

			System.out.println("Single Blacklisted Email was successful");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickUploadEmailBlacklistEmail() {

		try {
			driver.findElement(uploadMultipleBlacklistEmail).click();

			System.out.println("Upload Multiple Blacklist Email was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickChooseFileUpload() {

		try {
			driver.findElement(chooseFileUploadLatest).click();

			System.out.println("Choose File to Upload was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void UploadFileButton() {
		try {
			File file = new File("C:\\Users\\Ohia James\\Documents\\Zenithcresttechnologies\\Flutter4Business\\Flutterwave4Business\\fileUpload\\blacklist.csv");
			driver.findElement(chooseFileUploadLatest).sendKeys(file.getAbsolutePath());
			System.out.println("The File was uploaded");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	/*public void UploadButtonW() {
		try {
			WebElement browse = driver.findElement(By.xpath("//button[contains(text(),'Choose file')]"));
			browse.click().sendKeys ("C:\\Users\\PC\\Documents\\Zenithcrest\\f4b\\fileupload\\blacklist.csv");
			System.out.println("The File was uploaded");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}*/



	public void ClickBulkEmailBlacklist() {

		try {
			driver.findElement(bulkEmailBlacklistButton).click();

			System.out.println("Bulk Email Blacklist button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCardPanBlacklist() {

		try {
			driver.findElement(cardPanBlacklist).click();

			System.out.println("Card Pan Blacklist was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAddCardPanBlacklist() {

		try {
			driver.findElement(addCardPanBlacklist).click();

			System.out.println("Add Card Pan Blacklist was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAddSingleCardPanBlacklist() {

		try {
			driver.findElement(addSingleCardPan).click();

			System.out.println("Add Single Card Pan was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


	public void ClickAddSingleCardPanField1() {

		try {
			driver.findElement(addSingleCardPanDetails1).click();

			System.out.println("Add Single Card Pan field 1 was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAddSingleCardPanField2() {

		try {
			driver.findElement(addSingleCardPanDetails2).click();

			System.out.println("Add Single Card Pan field 2 was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterAddSingleCardPanField2(String text) {

		try {
			driver.findElement(addSingleCardPanDetails2).sendKeys(text);

			System.out.println("Card number entered into Single Card Pan field 2");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void EnterAddSingleCardPanField1(String text) {

		try {
			driver.findElement(addSingleCardPanDetails1).sendKeys(text);

			System.out.println("Card number entered into Single Card Pan field 1");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickBlacklistSingleCardPan() {

		try {
			driver.findElement(blacklistSingleCardPan).click();

			System.out.println("Blacklist single card pan button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void CardPanBlacklistedSuccessfullyIsDisplayed() {

		try {
			driver.findElement(cardPanBlacklistedSuccessMessage).isDisplayed();

			System.out.println("Card Pan Blacklisted Successfully is Displayed");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickIpAddressBlacklist() {

		try {
			driver.findElement(ipAddressBlacklist).click();

			System.out.println("IP Address blacklist was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickAddIpAddressBlacklist() {

		try {
			driver.findElement(addIpAddressBlacklist).click();

			System.out.println("Add IP Address blacklist was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAddSingleIpAddress() {

		try {
			driver.findElement(addSingleIpAddress).click();

			System.out.println("Single IP Address blacklist was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleIpAddressField() {

		try {
			driver.findElement(singleIpAddressField).click();

			System.out.println("Single IP Address field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterSingleIpAddress(String text) {

		try {
			driver.findElement(singleIpAddressField).sendKeys();

			System.out.println("IP Address was entered in the single IP Address field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBlacklistIpAddress() {

		try {
			driver.findElement(blacklistIpAddress).click();

			System.out.println("Blacklist IP Address button was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BlacklistIpAddressSuccessMessageIsDisplayed() {

		try {
			driver.findElement(blacklistIpAddressSuccessMessage).click();

			System.out.println("IP Address Blacklisted successfully");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

}
