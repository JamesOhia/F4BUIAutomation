package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePageObject {

	private By email = By.xpath("//input[@id='emailaddress']");
	private By password = By.xpath("//input[@id='password']");
	private By loginButton = By.xpath("//button[contains(text(),'Login')]");
	private By testMode = By.xpath("//span[contains(text(),'You are currently in Test mode and your daily limi')]");
	private By dashboard = By.xpath("//span[contains(text(),'Total Value')]");
	private By oldDashboard = By.xpath("//button[contains(text(),'Continue to the old')]");
	private By overview = By.xpath("//span[contains(text(),'Overview')]");
	private By avatar = By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/nav[1]/div[1]/div[6]/span[1]/img[1]");
	private By signOut = By.xpath("//div[contains(text(),'Sign out')]");
	private By errorMessage = By.xpath("//span[contains(text(),'Incorrect Email or Password')]");

	private WebDriver driver;

	public HomePageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickEmail() {

		try{
			driver.findElement(email).click();

			System.out.println("Email Input field was Clicked");

		}
		catch(Exception e) 
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearEmail() {

		try{
			driver.findElement(email).clear();

			System.out.println("Email Input field was Cleared");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterEmail(String text) {

		try{
			driver.findElement(email).sendKeys(text);

			System.out.println("Email was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPassword() {

		try{
			driver.findElement(password).click();

			System.out.println("password Input field was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearPassword() {

		try{
			driver.findElement(password).clear();

			System.out.println("Password Input field was Cleared");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPassword(String text) {

		try{
			driver.findElement(password).sendKeys(text);

			System.out.println("Password was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickLogin() {

		try{
			driver.findElement(loginButton).click();

			System.out.println("Login Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickOldDashboard() {

		try{
			driver.findElement(oldDashboard).click();

			System.out.println("Continue to the old Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TestModeMessageIsReturned() {

		try{
			driver.findElement(testMode).isDisplayed();

			System.out.println("Test Mode Message is displayed to user");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickOverviewButton() {
		try{
			driver.findElement(overview).click();
			System.out.println("Overview Menu button was clicked");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DashboardIsReturned() {

		try{
			driver.findElement(dashboard).isDisplayed();

			System.out.println("Dashboard is displayed to user");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void OverViewIsPresent() {

		try{
			driver.findElement(overview).isDisplayed();

			System.out.println("Overview on dashboard is displayed");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ErrorMessageIsDisplayed() {
		try{
			driver.findElement(errorMessage).isDisplayed();
			System.out.println("Error message was displayed to user");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAvatar() {
		try{
			driver.findElement(avatar).click();
			System.out.println("Avatar Menu was clicked");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSignOut() {
		try{
			driver.findElement(signOut).click();
			System.out.println("Sign out button Menu was clicked");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







