package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class ReferralPageObject {

	private By referrals       = By.xpath("//span[contains(text(),'Referrals')]");
	private By copyReferral    = By.xpath("//button[contains(text(),'copy')]");
	private By referralLink    = By.xpath("//a[contains(text(),'Your referral link')]");
	private By signup          = By.xpath("//div[contains(text(),\"Let's get you started with your Flutterwave account\")]");
	private By continueToOldDashboard = By.xpath("//button[contains(text(),'Continue to the old')]");



	private WebDriver driver;


	public ReferralPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickContinueToOldDashboard() {
		try{
			driver.findElement(continueToOldDashboard).click();
			System.out.println("The continue to old dashboard lable link was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickReferralButton() {
		try {
			driver.findElement(referrals).click();
			System.out.println("Referral button Menu was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickCopyButton() {
		try {
			driver.findElement(copyReferral).click();
			System.out.println("The Referral Code was copied");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	public void ClickReferralLink() {
		try {
			driver.findElement(referralLink).click();
			System.out.println("The Referral link was clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}


public void Navigate(){
		try{
			driver.navigate().to("https://dashboard.flutterwave.com/signup?referrals=RV745035");
			driver.findElement(signup).isDisplayed();
			System.out.println("The Signup page was displayed");

		}catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
}

	//Code to continue test if link opens in a new tab:






}




