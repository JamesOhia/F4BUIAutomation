package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class AirtimeDSTVObject {

	private By airtimeDstvButton = By.xpath("//span[contains(text(),'Airtime & DSTV')]");
	private By airtimePurchaseHeader = By.xpath("//a[contains(text(),'Airtime Purchase')]");
	private By buyAirtimeButton = By.xpath(" //button[contains(text(),'Buy Airtime')]");
	private By singleAirtimePurchase = By.xpath("//div[contains(text(),'Single Purchase')]");
	private By singleAirtimeCountryField = By.xpath("//div[@class = \"select\" and @xpath =\"1\"]");
	private By singleAirtimeNumberField = By.xpath("//input[@type=\"tel\" and @maxlength=\"10\"]");
	private By singleAirtimeNumberFieldGhs= By.xpath ("//input[@type = \"tel\" and @maxlength =\"9\"]");
	private By singleAirtimeAmountField = By.xpath("//input[@type=\"tel\" and @class=\"v-money form__input\"]");
	private By buySingleAirtime = By.xpath("(//button[@type=\"submit\" and @class=\"btn btn--primary\"])[3]");
	private By singleAirtimePurchaseSuccessMessage = By.xpath("//div[contains(text(),'Airtime Purchased Successfully')]");
	private By singleAirtimeInsufficientAmount = By.xpath("//div[contains(text(),'Amount must be greater than 10.0')]");
	private By singleAirtimeInvalidNumber = By.xpath("//div[contains(text(),'Invalid customer id')]");
	private By singleAirtimeNetworkField = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[2]/div[1]/select[1]");
	private By downloadAirtime = By.xpath("//span[contains(text(),'Download')]");
	private By airtimeFilterByButton = By.xpath("//span[contains(text(),'Filter By')]");
	private By downloadAirtimeSuccessMessage = By.xpath("//div[contains(text(),'Fetch Complete, Downloading...')");
	private By dateAirtimeFilterField1 = By.xpath("(//input[@name=\"date\" and @class=\"form__input form__input--sm\"])[1]");
	private By dateAirtimeFilterField2 = By.xpath("(//input[@name=\"date\" and @class=\"form__input form__input--sm\"])[2]");
	private By currencyAirtimeFilterField = By.xpath("//div[@class=\"select select__input\" and @style=\"width: 100%;\"]");
	private By phoneNumberAirtimeFilterField = By.xpath("//input[@type=\"number\" and @class=\"form__input form__input--sm\"]");
	private By airtimeFilterClearButton = By.xpath("//button[contains(text(),'clear')]");
	private By airtimeFilterButton = By.xpath("//button[contains(text(),'Filter')]");
	private By airtimeFilterByToday = By.xpath("(//input[@for=\"today_qswyfheb20\" and @class=\"overview-filter__item__link active\"]|//div[@class=\"filter__item\"])[4]");
	private By airtimeFilterBy7Days = By.xpath("(//input[@for=\"today_qswyfheb20\" and @class=\"overview-filter__item__link active\"]|//div[@class=\"filter__item\"])[5]");
	private By airtimeFilterBy30Days = By.xpath("(//input[@for=\"today_qswyfheb20\" and @class=\"overview-filter__item__link active\"]|//div[@class=\"filter__item\"])[6]");
	private By airtimeFilterByYear = By.xpath("(//input[@for=\"today_qswyfheb20\" and @class=\"overview-filter__item__link active\"]|//div[@class=\"filter__item\"])[7]");
	private By singleAirtimeNg = By.xpath("//option[contains(text(),'Nigeria')]");
	private By singleAirtimeGh = By.xpath("//option[contains(text(),'Ghana')]");
	private By singleAirtimeNetworkMtn = By.xpath("//option[contains(text(),'MTN')]");
	private By singleAirtimeCurrencyFilterNg= By.xpath("//div[@class = \"radio__item\" and @xpath =\"1\"]");
	private By singleAirtimeCurrencyFilterDoneButton= By.xpath (" //button[contains(text(),'Done')]");
	private By dSTVSubscription= By.xpath(" //a[contains(text(),'DSTV Subscription')]");
	private By buyDSTVSubscription= By.xpath(" //button[contains(text(),'Buy DSTV Subscription')]");
	private By buySingleDSTVSubscription= By.xpath(" //div[contains(text(),'Single purchase allows you buy a DSTV subscription')]");
	private By singleDSTVCountryField= By.xpath(" //body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[1]/select[1]\n");
	private By singleDSTVAmountField= By.xpath("//input[@type=\"tel\"and @class=\"v-money form__input\"]");
	private By singleDSTVSmartNumberField= By.xpath("(//input[@type=\"text\"and @class=\"form__input\"])[4]");
	private By buyDSTVButton=By.xpath("//button[contains(text(),'Buy Subscription')]");
	private By singleDSTVCountryNG= By.xpath ("//option[contains(text(),'Nigeria')]");
	private By singleDSTVInvalidNumber= By.xpath("//div[contains(text(),'Invalid Biller selected')]");
	private By singleDSTVSuccessMessage= By.xpath("");
	private By dSTVDownloadButton= By.xpath("//span[contains(text(),'Download')]");
	private By dSTVFilterBy= By.xpath("//span[contains(text(),'Filter By')]");
	private By dSTVDateFilterField1= By.xpath("(//input[@name=\"date\" and @readonly=\"readonly\"])[1]");
	private By dSTVDateFilterField2= By.xpath("(//input[@name=\"date\" and @readonly=\"readonly\"])[2]");
	private By bulkAirtimePurchase= By.xpath("//div[contains(text(),'Bulk Purchase')]");
	private By bulkAirtimeUpload= By.xpath("//button[contains(text(),'Choose file')]");
	private By buyBulkAirtime= By.xpath("//button[contains(text(),'Buy Airtime')]");
	private By bulkAirtimeSuccessMessage= By.xpath("//div[contains(text(),'Bulk Purchase queued successfully')]");
	private By buyBulkAirtimeLatest= By.xpath("///body/div[@id='app']/div[1]/div[1]/main[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[2]/button[2]");

	//	private By singleAirtimePurchaseSuccessMessage



	private WebDriver driver;

	public AirtimeDSTVObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickAirtimeDSTVButton() {

		try {
			driver.findElement(airtimeDstvButton).click();

			System.out.println("AirtimeDSTV button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAirtimePurchaseHeader() {

		try {
			driver.findElement(airtimePurchaseHeader).click();

			System.out.println("Airtime Purchase Header was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBuyAirtimeButton() {

		try {
			driver.findElement(buyAirtimeButton).click();

			System.out.println("Buy Airtime button was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimePurchase() {

		try {
			driver.findElement(singleAirtimePurchase).click();

			System.out.println("Single Airtime Purchase was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeCountryField() {

		try {
			driver.findElement(singleAirtimeCountryField).click();

			System.out.println("Single Airtime country field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeNG() {

		try {
			driver.findElement(singleAirtimeNg).click();

			System.out.println("Single Airtime NG was selected");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeGH() {

		try {
			driver.findElement(singleAirtimeGh).click();

			System.out.println("Single Airtime GH was selected");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimePhoneNumberField() {

		try {
			driver.findElement(singleAirtimeNumberField).click();

			System.out.println("Single Airtime Phone Number Field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterSingleAirtimePhoneNumber(String text) {

		try {
			driver.findElement(singleAirtimeNumberField).sendKeys(text);

			System.out.println("Phone Number was entered into the number field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeNetworkField() {

		try {
			driver.findElement(singleAirtimeNetworkField).click();

			System.out.println("Single Airtime Network Field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeNetworkMTN() {

		try {
			driver.findElement(singleAirtimeNetworkMtn).click();

			System.out.println("Single Airtime Network  was selected");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickSingleAirtimeAmountField() {

		try {
			driver.findElement(singleAirtimeAmountField).click();

			System.out.println("Single Airtime Amount field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeNumberFieldGhs() {

		try {
			driver.findElement(singleAirtimeNumberFieldGhs).click();

			System.out.println("Single Airtime Gh Number field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterSingleAirtimeAmount(String text) {

		try {
			driver.findElement(singleAirtimeAmountField).sendKeys(text);

			System.out.println("Amount was entered into the amount field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterSingleAirtimeNumberFieldGhs(String text) {

		try {
			driver.findElement(singleAirtimeNumberFieldGhs).sendKeys(text);

			System.out.println("Amount was entered into the amount field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickBuySingleAirtime() {

		try {
			driver.findElement(buySingleAirtime).click();

			System.out.println("Buy Single Airtime Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SingleAirtimePurchaseSuccessMessageIsDisplayed() {

		try {
			driver.findElement(singleAirtimePurchaseSuccessMessage).isDisplayed();

			System.out.println("Single Airtime Purchase Successful");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void SingleAirtimeInvalidNumberIsDisplayed() {

		try {
			driver.findElement(singleAirtimeInvalidNumber).isDisplayed();

			System.out.println("Single Airtime Purchase Successful");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SingleAirtimeInsufficientAmountIsDisplayed() {

		try {
			driver.findElement(singleAirtimeInsufficientAmount).isDisplayed();

			System.out.println("Single Airtime Purchase Successful");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickAirtimeFilterByButton() {

		try {
			driver.findElement(airtimeFilterByButton).click();

			System.out.println("Airtime Filter By Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterByTodayButton() {

		try {
			driver.findElement(airtimeFilterByToday).click();

			System.out.println("Airtime Filter By Today Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterBy7DaysButton() {

		try {
			driver.findElement(airtimeFilterBy7Days).click();

			System.out.println("Airtime Filter By 7 Days Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterBy30DaysButton() {

		try {
			driver.findElement(airtimeFilterBy30Days).click();

			System.out.println("Airtime Filter By 30 Days Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterByYearButton() {

		try {
			driver.findElement(airtimeFilterByYear).click();

			System.out.println("Airtime Filter By Year Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDateAirtimeFilterField1() {

		try {
			driver.findElement(dateAirtimeFilterField1).click();

			System.out.println("Date Filter Field 1 was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDateAirtimeFilterField2() {

		try {
			driver.findElement(dateAirtimeFilterField2).click();

			System.out.println("Date Filter Field 2 was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDateAirtimeFilterField1(String text) {

		try {
			driver.findElement(dateAirtimeFilterField1).sendKeys(text);

			System.out.println("Date was entered into the date field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDateAirtimeFilterField2(String text) {

		try {
			driver.findElement(dateAirtimeFilterField2).sendKeys(text);

			System.out.println("Date was entered into the date field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrencyAirtimeFilter() {

		try {
			driver.findElement(currencyAirtimeFilterField).click();

			System.out.println("Airtime Currency Filter Field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleAirtimeCurrencyFilter() {

		try {
			driver.findElement(singleAirtimeCurrencyFilterNg).click();

			System.out.println("currency was entered into the currency field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	public void ClickSingleAirtimeCurrencyFilterDoneButton() {

		try {
			driver.findElement(singleAirtimeCurrencyFilterDoneButton).click();

			System.out.println("Airtime Filter Done Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPhoneNumberAirtimeFilter() {

		try {
			driver.findElement(phoneNumberAirtimeFilterField).click();

			System.out.println("Airtime Phone Number Filter Field was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPhoneNumberAirtimeFilter(String text) {

		try {
			driver.findElement(phoneNumberAirtimeFilterField).sendKeys(text);

			System.out.println("Phone Number was entered into the phone number field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickFilterButton() {

		try {
			driver.findElement(airtimeFilterButton).click();

			System.out.println("Airtime Filter Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickDownloadAirtimeButton() {

		try {
			driver.findElement(downloadAirtime).click();

			System.out.println("Download Airtime Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBulkAirtimePurchase() {

		try {
			driver.findElement(bulkAirtimePurchase).click();
			System.out.println("Buy Airtime Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBulkAirtimeUpload() {
		try {
			File file = new File("C:\\Users\\PC\\Documents\\Zenithcrest\\f4b\\fileupload\\sample-bulk-airtime (1).csv");
			driver.findElement(bulkAirtimeUpload).sendKeys(file.getAbsolutePath());
			System.out.println("The file was uploaded");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

		public void ClickBuyBulkAirtime() {

			try {
				driver.findElement(buyBulkAirtimeLatest).click();
				System.out.println("Buy Bulk Airtime Button was Clicked");

			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}

			public void BulkAirtimeSuccessMessageIsDisplayed() {

				try {
					driver.findElement(bulkAirtimeSuccessMessage).isDisplayed();

					System.out.println("Bulk Purchase queued successfully");

				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			}



	public void ClickDSTVSubscription() {

		try {
			driver.findElement(dSTVSubscription).click();

			System.out.println("The DSTV Subscription header was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickBuyDSTVSubscription() {

		try {
			driver.findElement(buyDSTVSubscription).click();

			System.out.println("The Buy DSTV Subscription Label was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleDSTVSubscription() {

		try {
			driver.findElement(buySingleDSTVSubscription).click();

			System.out.println("The Buy Single DSTV Subscription Label was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleDSTVCountryField() {

		try {
			driver.findElement(singleDSTVCountryField).click();

			System.out.println("The Single DSTV Country Field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickSingleDSTVNGField() {

		try {
			driver.findElement(singleDSTVCountryNG).click();

			System.out.println("Country Nigeria was selected");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleDSTVAmountField() {

		try {
			driver.findElement(singleDSTVAmountField).click();

			System.out.println("The Single DSTV Amount Field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterSingleDSTVAmountField(String text) {

		try {
			driver.findElement(singleDSTVAmountField).sendKeys(text);

			System.out.println("Number was entered into the amount field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickSingleDSTVSmartNumberField() {

		try {
			driver.findElement(singleDSTVSmartNumberField).click();

			System.out.println("The Single DSTV Smart Number Field was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterSingleDSTVSmartNumber(String text) {

		try {
			driver.findElement(singleDSTVSmartNumberField).sendKeys(text);

			System.out.println("Number was entered into the Smart Number field");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBuyDSTVButton() {

		try {
			driver.findElement(buyDSTVButton).click();

			System.out.println("The Buy Subscription button was clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

	}
	/*public void DownloadAirtimeSuccessMessageIsDisplayed() {

		try {
			driver.findElement(downloadAirtimeSuccessMessage).isDisplayed();

			System.out.println("Download DSTV successful message was displayed");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
*/

	public void ClickDownloadDSTVButton() {

		try {
			driver.findElement(dSTVDownloadButton).click();

			System.out.println("Download DSTV Button was Clicked");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DownloadAirtimeSuccessMessageIsDisplayed() {

		try {
			driver.findElement(downloadAirtimeSuccessMessage).isDisplayed();

			System.out.println("Download Airtime successful message was displayed");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
}