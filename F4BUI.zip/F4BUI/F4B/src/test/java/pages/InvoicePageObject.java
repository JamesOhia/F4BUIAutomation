package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class InvoicePageObject {

	private By clickInvoicesTab = By.xpath("(//span[contains(text(), \"Invoices\")])[1]");

	//Filter Invoices
	private By filteredButton = By.xpath("(//span[contains(text(),'Invoices')])[3]");
	private By filteredToday = By.xpath("(//label[contains(text(),\"Today\")])[1]");
	private By filteredLast7Days = By.xpath("(//label[contains(text(),\"Last 7 days\")])[1]");
	private By filtered30Days = By.xpath("(//label[contains(text(),\"30 days\")])[1]");
	private By filtered1Year = By.xpath("(//label[contains(text(),\"1 year\")])[1]");
	private By filteredDue = By.xpath("//label[contains(text(),'Due')]");
	private By filteredPaid = By.xpath("//label[contains(text(),'Paid')]");
	private By filteredIssued = By.xpath("//label[contains(text(),'Issued')]");
	private By filteredDraft = By.xpath("//label[contains(text(),'Draft')]");
	private By filteredClear = By.xpath("//button[contains(text(),'clear')]");
	private By filteredFilter = By.xpath("//button[contains(text(),'Filter')]");

	//New Invoice
	private By clickNewInvoice = By.xpath("//button[contains(text(),'New Invoice')]");
	private By clickEmail = By.xpath("//input[@placeholder = \"Enter Email Address\"]");
	private By clickDropDownEmail = By.xpath("//div[contains(text(),'Ade Ade - adewale.a@zenithcresttechnologies.com')]");
	private By clickDueDate = By.xpath("//input[@placeholder = \"Click to Enter Due Date\"]");
	private By selectDueToday = By.xpath("//td[@class = \"curMonth today current\"]");
	private By clickCurrency = By.xpath("(//select[@class = \"select__input\"])[1]");
	private By selectCurrency = By.xpath("//option[@value = \"NGN\"]");
	private By enterInvoiceItem = By.xpath("(//input[@class = \"form__input\"])[7]");
	private By enterQuantity = By.xpath("(//input[@class = \"v-money form__input\"])[1]");
	private By enterUnitPrice = By.xpath("(//input[@class = \"v-money form__input\"])[2]");
	private By enterInvoiceNotes = By.xpath("//textarea[@class = \"form__input\"]");
	private By clickBackInvoice = By.xpath("//div[contains(text(),'Invoices')]");
	private By clickSaveInvoice = By.xpath("//button[contains(text(),'Save Invoice')]");
	private By clickSendInvoice = By.xpath("//button[contains(text(),'Send Invoice')]");


	private By invoiceSent = By.xpath("//div[contains(text(),'Invoice has been sent successfully')]");

	//Download Invoice
	private By downloadInvoice = By.xpath("//span[contains(text(),'Download')]");
	private By invoiceDownloaded = By.xpath("//div[contains(text(),'Fetching Download...')]");

	//Send Invoice Negative scenarios
	private By noEmailAddressInvoices = By.xpath("//span[contains(text(),'Please choose a customer or create a new customer')]");
	private By noInvoiceItem = By.xpath("//span[contains(text(),'Please fill the invoice item, quantity and unit pr')]");

	//Created Invoice
	private By clickCreatedInvoice = By.xpath("//p[contains(text(),'adewale.a@zenithcresttechnologies.com')]");

	//InvoiceRemindDates
	private By invoiceReminded = By.xpath("//div[contains(text(),'Reminder has been created successfully')]");
	private By invoice14DaysBefore = By.xpath("//label[contains(text(),'14 days before')]");
	private By invoice7DaysBefore = By.xpath("//label[contains(text(),'7 days before')]");
	private By invoice3DaysBefore = By.xpath("//label[contains(text(),'3 days before')]");
	private By invoiceOnDueDate = By.xpath("//label[contains(text(),'On due date')]");
	private By invoice3DaysAfter = By.xpath("//label[contains(text(),'3 days after')]");
	private By invoice7DaysAfter = By.xpath("//label[contains(text(),'7 days after')]");
	private By invoice14DaysAfter = By.xpath("//label[contains(text(),'14 days after')]");

	//Invoice Edit
	private By editInvoiceMenu = By.xpath("(//span[contains(text(),'Edit Invoice')])[1]");
	private By editInvoiceSelect = By.xpath("(//span[contains(text(),'Edit Invoice')])[2]");
	private By invoiceEdited = By.xpath("//div[contains(text(),'Invoice has been modified successfully')]");
	private By resendInvoiceMenu = By.xpath("//span[contains(text(),'Resend Invoice')]");
	private By resendInvoiceButton = By.xpath("//button[contains(text(),'Resend Invoice')]");
	private By invoiceResent = By.xpath("//div[contains(text(),'Invoice has been resent successfully')]");

	//MarkPayment
	private By markAsPaid = By.xpath("//button[contains(text(),'Mark as Paid')]");
	private By enterDatePaid = By.xpath("//input[@name = 'date']");
	private By dateSelectPaid = By.xpath("//td[contains(text(),'20')]");
	private By submitPaid = By.xpath("//button[contains(text(),'Submit')]");
	private By invoicePaid = By.xpath("//div[contains(text(),'Invoice has been paid successfully')]");
	private By noDatePaid = By.xpath("//span[contains(text(),'Please select a payment date')]");
	private By sendReceipt = By.xpath("//button[contains(text(),'Send Receipt')]");
	private By paymentReceiptSent = By.xpath("//div[contains(text(),'Payment Receipt has been sent successfully')]");

	//DeleteInvoice
	private By deleteInvoice = By.xpath("//button[contains(text(),'Delete Invoice')]");
	private By invoiceDeleted = By.xpath("//div[contains(text(),'Invoice deleted successfully')]");

	private WebDriver driver;

	public InvoicePageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ScrollUp(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, -500)");
		System.out.println("Scrolled Page Up");
	}

	public void ScrollDown(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, 500)");
		System.out.println("Scrolled Page Down");
	}

	public void NavigateDown() {
		EventFiringWebDriver eventFiringWebDriver = new EventFiringWebDriver(driver);//Create the object
		//Execute the scrolling down script using css selector element
		eventFiringWebDriver.executeScript("document.querySelector('body.nprogress-container:nth-child(2) div:nth-child(1) div.positionRelative div.padTop--50 div:nth-child(3) > nav.nav.nav--sidebar.nav--sidebar-bannerPresent:nth-child(2)').scrollTop = 500");
		System.out.println("Scrolled Inner Scroll down");
	}

	public void ClickInvoicesTab() {

		try{
			driver.findElement(clickInvoicesTab).click();

			System.out.println("Invoice Tab was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Filter Invoices
	public void ClickFilteredButton() {

		try{
			driver.findElement(filteredButton).click();

			System.out.println("Filtered Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredToday() {

		try{
			driver.findElement(filteredToday).click();

			System.out.println("Filtered Today Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredLast7Days() {

		try{
			driver.findElement(filteredLast7Days).click();

			System.out.println("Filtered Last 7 Days Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFiltered30Days() {

		try{
			driver.findElement(filtered30Days).click();

			System.out.println("Filtered 30 Days Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFiltered1Year() {

		try{
			driver.findElement(filtered1Year).click();

			System.out.println("Filtered 1 Year Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterDue() {

		try{
			driver.findElement(filteredDue).click();

			System.out.println("Due Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredPaid() {

		try{
			driver.findElement(filteredPaid).click();

			System.out.println("Paid Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredIssued() {

		try{
			driver.findElement(filteredIssued).click();

			System.out.println("Issued Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredDraft() {

		try{
			driver.findElement(filteredDraft).click();

			System.out.println("Draft Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickClearFilter() {

		try{
			driver.findElement(filteredClear).click();

			System.out.println("Filter was Cleared");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredFilter() {

		try{
			driver.findElement(filteredFilter).click();

			System.out.println("Filtered Button was Clicked and filtered");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//New Invoice
	public void ClickNewInvoice() {

		try{
			driver.findElement(clickNewInvoice).click();

			System.out.println("New Invoice Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickEmailAddress() {

		try{
			driver.findElement(clickEmail).click();

			System.out.println("Email Address Field Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDropDownEmail() {

		try{
			driver.findElement(clickDropDownEmail).click();

			System.out.println("Email Address Drop-Down was Selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDueDate() {

		try{
			driver.findElement(clickDueDate).click();

			System.out.println("Due Date was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectDueToday() {

		try{
			driver.findElement(selectDueToday).click();

			System.out.println("Today Due Date was Selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrency() {

		try{
			driver.findElement(clickCurrency).click();

			System.out.println("Currency was Clicked");

		}
		catch(Exception e) 
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SelectCurrency() {

		try{
			driver.findElement(selectCurrency).click();

			System.out.println("Currency was Selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearInvoiceItem() {

		try{
			driver.findElement(enterInvoiceItem).clear();

			System.out.println("Invoice Item was cleared");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterInvoiceItem(String text) {

		try{
			driver.findElement(enterInvoiceItem).sendKeys(text);

			System.out.println("Invoice Item was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterQuantity(String text) {

		try{
			driver.findElement(enterQuantity).sendKeys(text);

			System.out.println("Quantity was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterUnitPrice(String text) {

		try{
			driver.findElement(enterUnitPrice).sendKeys(text);

			System.out.println("Unit Price was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterInvoiceNotes(String text) {

		try{
			driver.findElement(enterInvoiceNotes).sendKeys(text);

			System.out.println("Invoice Notes was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBackInvoice() {

		try{
			driver.findElement(clickBackInvoice).click();

			System.out.println("Back Invoices Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DownloadInvoice() {

		try{
			driver.findElement(downloadInvoice).click();

			System.out.println("Invoice download button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceDownloaded() {

		try{
			driver.findElement(invoiceDownloaded).isDisplayed();

			System.out.println("Invoice was downloaded");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoEmailAddressInvoices() {

		try{
			driver.findElement(noEmailAddressInvoices).isDisplayed();

			System.out.println("Please choose a customer or create a new customer error message is displayed ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoInvoiceItem() {

		try{
			driver.findElement(noInvoiceItem).isDisplayed();

			System.out.println("Please fill the invoice item, quantity and unit price error message is displayed ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSaveInvoice() {

		try{
			driver.findElement(clickSaveInvoice).click();

			System.out.println("Invoice was saved");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSendInvoice() {

		try{
			driver.findElement(clickSendInvoice).click();

			System.out.println("Invoice was sent");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCreatedInvoice() {

		try{
			driver.findElement(clickCreatedInvoice).click();

			System.out.println("Created Invoice is opened");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public boolean CreatedInvoiceDisplayed() {

		try{
			driver.findElement(clickCreatedInvoice).isDisplayed();

			return true;

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void Invoice14DaysBefore() {

		try{
			driver.findElement(invoice14DaysBefore).click();

			System.out.println("Invoice 14 Days Before box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceReminded() {

		try{
			driver.findElement(invoiceReminded).isDisplayed();

			System.out.println("Reminder has been created successfully'");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Invoice7DaysBefore() {

		try{
			driver.findElement(invoice7DaysBefore).click();

			System.out.println("Invoice 7 Days Before box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Invoice3DaysBefore() {

		try{
			driver.findElement(invoice3DaysBefore).click();

			System.out.println("Invoice 3 Days Before box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceOnDueDate() {

		try{
			driver.findElement(invoiceOnDueDate).click();

			System.out.println("Invoice on due date box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Invoice3DaysAfter() {

		try{
			driver.findElement(invoice3DaysAfter).click();

			System.out.println("Invoice 3 Days After box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Invoice7DaysAfter() {

		try{
			driver.findElement(invoice7DaysAfter).click();

			System.out.println("Invoice 7 Days After box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Invoice14DaysAfter() {

		try{
			driver.findElement(invoice14DaysAfter).click();

			System.out.println("Invoice 14 Days After box is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EditInvoiceMenu() {

		try{
			driver.findElement(editInvoiceMenu).click();

			System.out.println("Edit Invoice Menu is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ResendInvoiceMenu() {

		try{
			driver.findElement(resendInvoiceMenu).click();

			System.out.println("Resend Invoice Menu is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ResendInvoiceButton() {

		try{
			driver.findElement(resendInvoiceButton).click();

			System.out.println("Resend Invoice Button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceResent() {

		try{
			driver.findElement(invoiceResent).isDisplayed();

			System.out.println("Invoice has been resent successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EditInvoiceSelect() {

		try{
			driver.findElement(editInvoiceSelect).click();

			System.out.println("Edit Invoice Select is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void InvoiceEdited() {

		try{
			driver.findElement(invoiceEdited).isDisplayed();

			System.out.println("Invoice has been modified successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void MarkAsPaid() {

		try{
			driver.findElement(markAsPaid).click();

			System.out.println("Mark As Paid is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDatePaid() {

		try{
			driver.findElement(enterDatePaid).click();

			System.out.println("Payment Date is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DateSelectPaid() {

		try{
			driver.findElement(dateSelectPaid).click();

			System.out.println("Payment Date is selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SubmitPaid() {

		try{
			driver.findElement(submitPaid).click();

			System.out.println("Submit Button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NoDatePaid() {

		try{
			driver.findElement(noDatePaid).isDisplayed();

			System.out.println("Please select a payment date error message is displayed");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoicePaid() {

		try{
			driver.findElement(invoicePaid).isDisplayed();

			System.out.println("Invoice has been paid successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void SendReceipt() {

		try{
			driver.findElement(sendReceipt).click();

			System.out.println("Send Receipt Button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void PaymentReceiptSent() {

		try{
			driver.findElement(paymentReceiptSent).isDisplayed();

			System.out.println("Payment Receipt has been sent successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeleteInvoice() {

		try{
			driver.findElement(deleteInvoice).click();

			System.out.println("Delete Invoice Button is clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceDeleted() {

		try{
			driver.findElement(invoiceDeleted).isDisplayed();

			System.out.println("Invoice deleted successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvoiceSent() {

		try{
			driver.findElement(invoiceSent).isDisplayed();

			System.out.println("Invoice has been sent successfully");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







