package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BalancePageObject {

	private By balance = By.xpath("//span[contains(text(),'Balance')]");
	private By editLimit = By.xpath("//button[contains(text(),'Edit Limit')]");
	private By setLimit = By.xpath("//button[contains(text(),'Set Limit')]");
	private By removeLimit = By.xpath("//button[contains(text(),'Remove Limit')]");
	private By limitAmount = By.xpath("\t//input [@type = 'text' and @class = 'v-money form__input']\n");
	private By submitBtn = By.xpath("//button[contains(text(),'Set Limit') and @type = 'submit']\n");
	private By limitAdded = By.xpath("//div[contains(text(),'Threshold successfully modified')]");
	private By limitRemoved = By.xpath("//div[contains(text(),'Threshold successfully removed')]");
	private By balTransfer = By.xpath("\t//a[contains(text(),'transfers')]\n");
	private By topUp = By.xpath("//button[contains(text(),'Topup')]");
	private By topupModal = By.xpath("//div[contains(text(),'Topup Balance')]");
	private By copyAccNum = By.xpath("//button [@data-clipboard-text='1352506507']");
	private By balanceHistory = By.xpath("//div[contains(text(),'Balance History')]");
	private By filteredBy = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span[2]/span[3]");
	private By last7Days = By.xpath("//label [contains(text(),'Last 7 days')]");
	private By startDate = By.xpath("//div [@class = 'mx-datepicker'] | //input [@placeholder ='Start Date']");
	private By filterType = By.xpath("//label [contains(text(),'Debit')]");
	private By filterButton = By.xpath("//button [contains(text(),'Filter')]");
	private By downloadBtn = By.xpath("\t//span[contains(text(),'Download')]");
	private By csvOption = By.xpath("//div[contains(text(),'CSV')]");
	private By balanceStatement = By.xpath("\t//div[contains(text(),'Balance Statement')]\n");

	private By continueToOldDashboard = By.xpath("\t//button[contains(text(),'Continue to the old')]");



	private WebDriver driver;

	public BalancePageObject(WebDriver driver) {
		this.driver = driver;
	}


	public void ClickContinueToOldDashboard() {
		try{
			driver.findElement(continueToOldDashboard).click();
			System.out.println("The continue to old dashboard lable link was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBalance() {
		try{
			driver.findElement(balance).click();
			System.out.println("Balance button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickEditLimit() {
		try{
			driver.findElement(editLimit).click();
			System.out.println("The Edit Limit button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSetLimit() {
		try{
			driver.findElement(setLimit).click();
			System.out.println("The Set Limit button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickLimitAmount() {
		try{
			driver.findElement(limitAmount).click();
			System.out.println("The How much do you want to set as your limit? field was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearLimitAmount() {
		try{
			driver.findElement(limitAmount).clear();
			System.out.println("The How much do you want to set as your limit? field was cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterLimitAmount(String text) {
		try{
			driver.findElement(limitAmount).sendKeys(text);
			System.out.println("Text was entered into the How much do you want to set as your limit? field");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSubmitButton() {
		try{
			driver.findElement(submitBtn).click();
			System.out.println("The Submit button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void LimitAddedSuccessfully() {
		try{
			driver.findElement(limitAdded).isDisplayed();
			System.out.println("Threshold successfully modified is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void LimitRemovedSuccessfully() {
		try{
			driver.findElement(limitRemoved).isDisplayed();
			System.out.println("Threshold successfully removed is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickRemoveLimit() {
		try{
			driver.findElement(removeLimit).click();
			System.out.println("The Remove Limit button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBalTransfer() {
		try {
			driver.findElement(balTransfer).click();
			System.out.println("The transfers label link was Clicked");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTopUp() {
		try{
			driver.findElement(topUp).click();
			System.out.println("The Topup button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TopupBalanceModal() {
		try{
			driver.findElement(topupModal).isDisplayed();
			System.out.println("The Topup Balance Modal is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCopyAccountNumber() {
		try{
			driver.findElement(copyAccNum).click();
			System.out.println("The Copy button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBalanceHistory() {
		try{
			driver.findElement(balanceHistory).click();
			System.out.println("The Balance History tab was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilteredBy() {
		try{
			driver.findElement(filteredBy).click();
			System.out.println("The Filtered By transactions button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickLast7Days() {
		try{
			driver.findElement(last7Days).click();
			System.out.println("The Last 7 days button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickFilterType() {
		try{
			driver.findElement(filterType).click();
			System.out.println("The Debit radio button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterButton() {
		try{
			driver.findElement(filterButton).click();
			System.out.println("The Filter button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickDownload() {
		try{
			driver.findElement(downloadBtn).click();
			System.out.println("The Download button was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
	public void ClickCSVOption() {
		try{
			driver.findElement(csvOption).click();
			System.out.println("The CSV option was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBalanceStatement() {
		try{
			driver.findElement(balanceHistory).click();
			System.out.println("The Balance Statement option was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







