package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MenuPageObject {

	private By transactions = By.xpath("//span[contains(text(),'Transactions')]");
	private By transDash = By.xpath("//div[contains(text(),'All Transactions')]");

	private WebDriver driver;

	public MenuPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ClickTransactionsButton() {
		try{
			driver.findElement(transactions).click();
			System.out.println("Transactions Menu button was clicked");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransDash() {
		try{
			driver.findElement(transDash).click();
			System.out.println("Transactions Dashboard is displayed to user");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







