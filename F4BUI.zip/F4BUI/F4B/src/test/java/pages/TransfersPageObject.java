package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import java.awt.Robot;
import java.io.File;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class 	TransfersPageObject {

	private By overview = By.xpath("//span[contains(text(),'Overview')]");
	private By dashboard = By.xpath("//span[contains(text(),'Total Value')]");
	private By transfer = By.xpath("//span[contains(text(),'Transfers')]");
	private By today = By.xpath("//label[contains(text(),'Today')]");
	private By last7Days = By.xpath("(//label[contains(text(),'Last 7 days')]) [1]");
	private By thirtyDays = By.xpath("//label[contains(text(),'30 days')]");
	private By oneYear = By.xpath("//label[contains(text(),'1 year')]");
	private By transfersNav = By.xpath("//a[contains(text(),'Transfers')]");
	private By filterBy = By.xpath("//span[contains(text(),'Filter By')]");
	private By last7DaysFilter = By.xpath("(//label[contains(text(),'Last 7 days')]) [1]");
	private By successfulFilter = By.xpath("//label[contains(text(),'Successful')]");
	private By currencyFilter = By.xpath("//div[contains(text(),'NGN')]");
	private By selectedCurrency = By.xpath("(//div [@class = 'checkbox__item'] | //label[contains(text(),'EUR')]) [5]");
	private By done = By.xpath("//button[contains(text(),'Done')]");
	private By filter = By.xpath("//button[contains(text(),'Filter')]");
	private By newTransfer = By.xpath("//span[contains(text(),'New Transfer')]");
	private By beneficiaryAccountNumber = By.xpath("//div[contains(text(),'0690000035')]");
	private By removeBtn = By.xpath("(//button [contains(text(),'Remove')]) [1]");
	private By removeBeneficiary = By.xpath("//button[contains(text(),'Remove Beneficiary')]");
	private By invalidAccountNumber = By.xpath("//span[contains(text(),'Account number entered is invalid')]");
	private By benefCancelBtn = By.xpath("(//button [contains(text(),'Cancel')]) [3]");
	private By beneficiaryExists = By.xpath("//span[contains(text(),'Beneficiary already exists.')]");
	private By awaitingApprovalScreen = By.xpath("//div[contains(text(),'Awaiting Approval')]");
	private By benefCheckBox = By.xpath("//label [@for = \"label0\" and @class=\"checkbox__label\"]");







    //Transfer To Bank Account
	private By transferToBankAccount = By.xpath("//div[contains(text(),'Transfer to Bank account')]");
	private By singleTransfer = By.xpath("//div[contains(text(),'Single transfer allows you transfer to one account')]");
	private By amount = By.xpath("//input [@type = 'tel' and @class = 'v-money form__input form__input--noLeftBorderRadius' and @autofocus='autofocus']");
	private By accountNumberBA = By.xpath("(//input [@type = 'text' and @required = 'required' and @class = 'form__input']) [1]");
	private By description = By.xpath("(//input [@type = 'text' and @placeholder = 'Optional']) [1]");
	private By confirmTransfer = By.xpath("(//button [contains(text(),'Confirm Transfer')]) [2]");
	private By confirm = By.xpath("(//button [contains(text(),'Confirm')]) [4]");
	private By transferProcessing = By.xpath("//div[contains(text(),'Single transfer queued for processing')]");
	private By bulkTransfer = By.xpath("//div[contains(text(),'Bulk Transfer')]");
	private By getBulkFile = By.xpath("//span[contains(text(),'Get a sample Bulk Disburse CSV file')]");
	private By invalidAccountDetails = By.xpath("//span [contains(text(),'Invalid Bank Account Details')]");
	private By insufficientFundsError = By.xpath("//span [contains(text(),'Insufficient funds. Please fund your balance to complete this transfer.')]\n");
	private By here = By.xpath("(//a [contains(text(),'here')]) [1]");
	private By continueToOldDashboard = By.xpath("//button[contains(text(),'Continue to the old')]");

	//Bulk Transfer to Bank Account
	private By bulkTransferBA = By.xpath("(//div [contains(text(),'Bulk Transfer')]) [1]");
	private By chooseFileBA = By.xpath("(//span[contains(text(),'Choose file to upload')]) [1]");




	//Transfer to Mobile Money
    private By transferToMobileMoney = By.xpath("//div[contains(text(),'Transfer to Mobile Money')]");
	private By singleTransferMM = By.xpath("(//div[contains(text(),'Single Transfer')]) [2]");
	private By selectCurrency = By.xpath("(//select [@class = 'select__input select__input--noRightBorderRadius']) [3]");
	private By selectGHS = By.xpath("(//option[contains(text(),'GHS')]) [2]");
	private By amountMM = By.xpath("(//input [@type = 'tel' and @class = 'v-money form__input form__input--noLeftBorderRadius' and @autofocus='autofocus']) [2]");
	private By selectNetwork = By.xpath("//option[contains(text(),'Select Network')]");
	private By mtnMobile = By.xpath("//option[contains(text(),'MTN Mobile')]");
	private By phoneNumberMM = By.xpath("(//input [@type= 'text' and @oninput=\"this.value=this.value.replace(/[^0-9]/g,'');\"]) [1]");
	private By beneficiaryName = By.xpath("(//input [@placeholder = 'Enter a beneficiary name']) [2]");
	private By descriptionMM = By.xpath("(//input [@type = 'text' and @placeholder = 'Optional' and @class = 'form__input']) [2]");
	private By confirmTransferMM = By.xpath("(//button[contains(text(),'Confirm Transfer') and @type = 'submit' and @class = 'btn btn--primary']) [3]\n");
	private By confirmMM = By.xpath("(//button [contains(text(),'Confirm') and @type= 'submit' and @class = 'btn btn--primary']) [5]");
	private By invalidMobileNumber = By.xpath("//span[contains(text(),\"This mobile number hasn't been registered on Barte\")]");
	private By insufficientFunds = By.xpath("(//span[contains(text(),\"Insufficient funds. Please fund your balance to complete this transfer.\")])[3]");


    //Transfer to Barter Account
    private By transferToBarterAccount = By.xpath("//div[contains(text(),'Transfer to Barter account')]");
    private By singleTransferBA =By.xpath("(//div[contains(text(),'Single Transfer')]) [3]");
	private By mobileNumber =By.xpath("//input [@placeholder = 'Enter a phone number' and @name = \"telephone\"]");
	private By amountBA = By.xpath("(//input [@type = 'tel' and @class = 'v-money form__input form__input--noLeftBorderRadius' and @autofocus='autofocus']) [3]");
	private By descriptionBA = By.xpath("(//input [@type = 'text' and @placeholder = 'Optional' and @class = 'form__input']) [3]");
	private By confirmTransferBA = By.xpath("(//button[contains(text(),'Confirm Transfer') and @type = 'submit' and @class = 'btn btn--primary']) [4]");
	//private By confirmBA = By.xpath("(//button [contains(text(),'Confirm') and @type= 'submit' and @class = 'btn btn--primary']) [2]");
	private By confirmBA = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[5]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[2]/div[2]/button[2]");
	private By cancelBtnBA = By.xpath("(//button[contains(text(),'Cancel')])[7]");



	//Transfer to Flutterwave Account
	private By transferToFlutterwaveAccount = By.xpath("//div[contains(text(),'Transfer to Flutterwave account')]");
	private By amountFA = By.xpath("//input [@type = 'tel' and @class=\"v-money form__input form__input--noLeftBorderRadius\"]");
	private By merchantID = By.xpath("//input [@type = 'text' and @placeholder = \"Enter recipient's merchant id\"]");
	private By requireApproval = By.xpath("(//option[contains(text(),'Select Approver')] | //select [@class = 'select__input']) [4]");
	private By selectedApprover = By.xpath("(//option[contains(text(),'Maurice Ezebuiro')]) [2]");
	private By transactionNote = By.xpath("//input [@type = 'text' and @placeholder = 'Optional']");
	private By confirmTransferFA = By.xpath("(//button[contains(text(),'Confirm Transfer') and @type = 'submit' and @class = 'btn btn--primary']) [2]");
	//private By confirmFA = By.xpath("(//button[contains(text(),'Confirm Transfer') and @type = 'submit' and @class = 'btn btn--primary']) [2]");
	private By confirmFA = By.xpath("//body/div[@id='app']/div[1]/div[1]/main[1]/div[8]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[2]/button[2]");
	private By dropDownIcon = By.xpath("//span [@class = 'svg-icon']");
	private By approve = By.xpath("//div[contains(text(),'Approve')]");
	private By disapprove = By.xpath("//div[contains(text(),'Disapprove')]");
	private By viewTransferDetails = By.xpath("//div[contains(text(),'View Transfer Details')]");
	private By backButton = By.xpath("//div [@class = 'page-url__icon']");
	private By transferDisapproved = By.xpath("//div[contains(text(),'Transfer has been successfully rejected')]");
	private By transferApproved = By.xpath("//div[contains(text(),'Transfer has been successfully approved')]");
	private By invalidMerchantID = By.xpath("//span[contains(text(),'Account not found. Please check that the Merchant ')]");
	private By goBack = By.xpath("(//span [contains(text(),'Go back')]) [3]");


	private By awaitingApproval = By.xpath("//a[contains(text(),'Awaiting approval')]");
	private By beneficiaries = By.xpath("//a[contains(text(),'Beneficiaries')]");
	private By newBeneficiary = By.xpath("//button [@data-target = '#newBeneficiaries']");
	private By selectCountry = By.xpath("//option[contains(text(),'Select Country')]");
	private By nigeria = By.xpath("//option[contains(text(),'Nigeria')]");
	private By selectBank = By.xpath("//option[contains(text(),'Select Bank')]");
	private By accessBank = By.xpath("//option[contains(text(),'Access Bank')]");
	private By accountNumber = By.xpath("//input [@placeholder = 'Account number']");
	private By addBeneficiarybtn = By.xpath("//button[contains(text(),'Add Beneficiary')]");
	private By beneficiaryAdded = By.xpath("//div[contains(text(),'Beneficiary was added successfully')]");
	private By checkbox = By.xpath("(//input [@type = 'checkbox' and @class = 'checkbox__input'] | //label [@class = 'checkbox__label']) [4]");
	private By deleteBtn = By.xpath("//button[contains(text(),'Delete')]");
	private By deletedBeneficiary = By.xpath("//div[contains(text(),'Selected Beneficiaries has been successfully delet')]");
	private By barterBeneficiary = By.xpath("//div[contains(text(),'Or add a Barter beneficiary')]");
	private By enterPhoneNumber = By.xpath("//input [@placeholder = 'Enter a phone number']");

	private By fundingHistory = By.xpath("//a[contains(text(),'Funding History')]");
	private By topupBalance = By.xpath("//span[contains(text(),'Topup Balance')]");
	private By fundWallet = By.xpath("(//select [@class= 'select__input']) [1]");
	private By selectUSD = By.xpath("(//option [@value= 'USD']) [1]");

	private By copyBtn = By.xpath("(//button [contains(text(),'Copy')])[1]");

	private By download = By.xpath("//span[contains(text(),'Download')]");

	//Transfer to USD Cash Pick-Up
	private By transferToUSDCashPickUp = By.xpath("(//div[contains(text(),'Transfer to USD Cash Pick-Up')])[1]");
	private By continueBtn = By.xpath("(//button [contains(text(),'Continue')])[2]");
	private By amountField = By.xpath("(//input [@class= 'v-money form__input form__input--noLeftBorderRadius'])[2]");
	private By selectBankCashPickup = By.xpath("(//option[contains(text(),'Select Bank')])[1]");
	private By zenithBankSelected = By.xpath("//option[contains(text(),'ZENITH BANK PLC')]");
	private By emailAddressField = By.xpath("//input [@type=\"email\" and @placeholder = \"Email Address\"]");
	private By phoneNumberField = By.xpath("//input [@required=\"required\" and @placeholder = \"Phone Number\"]");
	private By recipientAddress = By.xpath("//input [@type=\"text\" and @placeholder = \"Beneficiary Address\"]");
	private By confirmTransferCashPickup = By.xpath("(//button [contains(text(),'Confirm Transfer')]) [2]");
	private By confirmBtn = By.xpath("(//button [contains(text(),'Confirm')]) [4]");

	private By invalidNumber = By.xpath("//div[contains(text(),'Please provide a valid sender mobile number or upd')]");
	private By cancelBtn = By.xpath("(//button[contains(text(),'Cancel')])[6]");




	private WebDriver driver;

	public TransfersPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ScrollUpPage(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, -1000)");
	}

	public void ScrollDownPage(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, +1000)");
	}


	//Upload file
	public void ChooseFileBa() {
		try {
			File file = new File("C:\\Users\\Oyebo\\OneDrive\\Documents\\F4B_UI_Automation\\f4b\\UploadFiles\\ngn_disburse_sample.csv");
			driver.findElement(chooseFileBA).sendKeys(file.getAbsolutePath());
			System.out.println("Disburse File was uploaded");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DashboardIsReturned() {
		try{
			driver.findElement(dashboard).isDisplayed();
			System.out.println("The Dashboard is returned");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidMobileNumber() {
		try{
			driver.findElement(invalidMobileNumber).isDisplayed();
			System.out.println("The message, This mobile number hasn't been registered on Barter. However we'll create an account for them and prompt them to set up their account. is returned");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InsufficientFunds() {
		try{
			driver.findElement(insufficientFunds).isDisplayed();
			System.out.println("The message, This mobile number hasn't been registered on Barter. However we'll create an account for them and prompt them to set up their account. is returned");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBenefCheckBox() {
		try{
			driver.findElement(benefCheckBox).isDisplayed();
			System.out.println("The checkbox was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Overview() {
		try{
			driver.findElement(overview).isDisplayed();
			System.out.println("Overview is returned");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickOverview() {
		try{
			driver.findElement(overview).click();
			System.out.println("The Overview tab was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickContinueToOldDashboard() {
		try{
			driver.findElement(continueToOldDashboard).click();
			System.out.println("The continue to old dashboard lable link was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransfers() {
		try{
			driver.findElement(transfer).click();
			System.out.println("The Transfer button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickToday() {
		try{
			driver.findElement(today).click();
			System.out.println("The Today button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickLast7Days() {
		try{
			driver.findElement(last7Days).click();
			System.out.println("The Last 7 Days button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickThirtyDays() {
		try{
			driver.findElement(thirtyDays).click();
			System.out.println("The 30 Days button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickOneYear() {
		try{
			driver.findElement(oneYear).click();
			System.out.println("The 1 Year button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransfersNavigation() {
		try{
			driver.findElement(transfersNav).click();
			System.out.println("The transfers button was Clicked on the navigation panel");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFilterBy() {
		try{
			driver.findElement(filterBy).click();
			System.out.println("The Filterby button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickLast7DaysFilter() {
		try{
			driver.findElement(last7DaysFilter).click();
			System.out.println("The last 7 days filter option was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSuccessfulFilter() {
		try{
			driver.findElement(successfulFilter).click();
			System.out.println("The successful filter option was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrencyFilter() {
		try{
			driver.findElement(currencyFilter).click();
			System.out.println("The currency drop down field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDone() {
		try{
			driver.findElement(done).click();
			System.out.println("The Done button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}



	public void ClickFilter() {
		try{
			driver.findElement(filter).click();
			System.out.println("The Filter button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidAccountNumber() {
		try{
			driver.findElement(invalidAccountNumber).isDisplayed();
			System.out.println("Account number entered is invalid is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AwaitingApprovalScreen() {
		try{
			driver.findElement(awaitingApprovalScreen).isDisplayed();
			System.out.println("The Awaiting Approval Screen is returned");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}



	public void ClickSelectedCurrency() {
		try{
			driver.findElement(selectedCurrency).click();
			System.out.println("The USD currency was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAwaitingApproval() {
		try{
			driver.findElement(awaitingApproval).click();
			System.out.println("The Awaiting Approval button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewTransfer() {
		try{
			driver.findElement(newTransfer).click();
			System.out.println("The New transfer button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransferToBankAccount() {
		try{
			driver.findElement(transferToBankAccount).click();
			System.out.println("The Transfer to Bank Account option was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSingleTransfer() {
		try{
			driver.findElement(singleTransfer).click();
			System.out.println("The single transfer option was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
	public void ClickAmount() {
		try{
			driver.findElement(amount).click();
			System.out.println("The How much do you want to send? field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAmount() {

		try{
			driver.findElement(amount).clear();
			System.out.println("The How much do you want to send? Input field was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmount (String text) {

		try{
			driver.findElement(amount).sendKeys(text);
			System.out.println("Amount was entered into the The How much do you want to send? field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickAccountNumberBA() {
		try{
			driver.findElement(accountNumberBA).click();
			System.out.println("Account Number field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAccountNumberBA() {

		try{
			driver.findElement(accountNumberBA).clear();
			System.out.println("Account Number input field was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAccountNumberBA (String text) {

		try{
			driver.findElement(accountNumberBA).sendKeys(text);
			System.out.println("Account Number was entered into the Account Number field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDescription() {
		try{
			driver.findElement(description).click();
			System.out.println("The Description field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearDescription() {

		try{
			driver.findElement(description).clear();
			System.out.println("The Description Input field was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDescription (String text) {

		try{
			driver.findElement(description).sendKeys(text);
			System.out.println("Text was entered into the Description field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmTransfer() {
		try{
			driver.findElement(confirmTransfer).click();
			System.out.println("The Confirm Transfer button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirm() {
		try{
			driver.findElement(confirm).click();
			System.out.println("The Confirm button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransferProcessing() {
		try{
			driver.findElement(transferProcessing).isDisplayed();
			System.out.println("Single transfer queued for processing is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}



	public void ClickBulkTransfer() {
		try{
			driver.findElement(bulkTransfer).click();
			System.out.println("The Bulk Transfer button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickGetBulkFile() {
		try{
			driver.findElement(getBulkFile).click();
			System.out.println("The Get a sample Bulk Disburse CSV file label link was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidAccountDetails() {
		try{
			driver.findElement(invalidAccountDetails).isDisplayed();
			System.out.println("Invalid Bank Account Details is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InsufficientFundsError() {
		try{
			driver.findElement(insufficientFundsError).isDisplayed();
			System.out.println("Insufficient funds. Please fund your balance to complete this transfer is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickHere() {
		try{
			driver.findElement(here).click();
			System.out.println("The here label link was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}






	public void ClickBeneficiaries() {
		try{
			driver.findElement(beneficiaries).click();
			System.out.println("The Beneficiaries button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNewBeneficiary() {
		try{
			driver.findElement(newBeneficiary).click();
			System.out.println("The New Beneficiary button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickSelectCountry() {
		try{
			driver.findElement(selectCountry).click();
			System.out.println("The Select Country drop down field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickNigeria() {
		try{
			driver.findElement(nigeria).click();
			System.out.println("Nigeria was selected from the Select Country field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectBank() {
		try{
			driver.findElement(selectBank).click();
			System.out.println("The Select Bank field was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAccessBank() {
		try{
			driver.findElement(accessBank).click();
			System.out.println("Access Bank was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAccountNumber() {

		try{
			driver.findElement(accountNumber).click();
			System.out.println("The Account Number field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAccountNumber() {

		try{
			driver.findElement(accountNumber).clear();
			System.out.println("The Account Number Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAccountNumber (String text) {

		try{
			driver.findElement(accountNumber).sendKeys(text);
			System.out.println("Account number was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAddBeneficiaryBtn() {
		try{
			driver.findElement(addBeneficiarybtn).click();
			System.out.println("The Add Beneficiary button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BeneficiaryAdded() {
		try{
			driver.findElement(beneficiaryAdded).isDisplayed();
			System.out.println("Beneficiary was added successfully is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCheckBox() {
		try{
			driver.findElement(checkbox).click();
			System.out.println("The Checkbox was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBeneficiaryAccountNumber() {
		try{
			driver.findElement(beneficiaryAccountNumber).click();
			System.out.println("TThe newly added beneficiary was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickRemoveBtn() {
		try{
			driver.findElement(removeBtn).click();
			System.out.println("The Remove button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickRemoveBeneficiary() {
		try{
			driver.findElement(removeBeneficiary).click();
			System.out.println("The Remove Beneficiary button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDeleteBtn() {
		try{
			driver.findElement(deleteBtn).click();
			System.out.println("The Delete button was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BeneficiaryDeleted() {
		try{
			driver.findElement(deletedBeneficiary).isDisplayed();
			System.out.println("Selected Beneficiaries has been successfully delet is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickBenefCancelButton() {
		try{
			driver.findElement(benefCancelBtn).click();
			System.out.println("The Cancel was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BeneficiaryExists() {
		try{
			driver.findElement(beneficiaryExists).isDisplayed();
			System.out.println("The Beneficiary already exists message is returned");
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAddBarterBeneficiary() {
		try{
			driver.findElement(barterBeneficiary).click();
			System.out.println("The OR ADD BARTER BENEFICIARY label link was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPhoneNumber() {

		try{
			driver.findElement(enterPhoneNumber).click();
			System.out.println("The Enter a Phone Number field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearPhoneNumber() {

		try{
			driver.findElement(enterPhoneNumber).clear();
			System.out.println("The Enter a Phone Number Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPhoneNumber (String text) {

		try{
			driver.findElement(enterPhoneNumber).sendKeys(text);
			System.out.println("Phone number was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickFundingHistory() {
		try{
			driver.findElement(fundingHistory).click();
			System.out.println("The Select Bank field was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTopupBalance() {
		try{
			driver.findElement(topupBalance).click();
			System.out.println("The Topup Balance button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCopyButton() {
		try{
			driver.findElement(copyBtn).click();
			System.out.println("The Copy button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDownload() {
		try{
			driver.findElement(download).click();
			System.out.println("The download button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

    public void ClickTransferToMobileMoney() {
        try{
            driver.findElement(transferToMobileMoney).click();
            System.out.println("The Transfer to Mobile Money option was clicked");
        } catch(Exception e)
        {
            throw new RuntimeException(e.getMessage());
        }
    }

	public void ClickSingleTransferMM() {
		try{
			driver.findElement(singleTransferMM).click();
			System.out.println("The Single Transfer option was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickSelectCurrency() {
		try{
			driver.findElement(selectCurrency).click();
			System.out.println("The currency drop-down was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectGHS() {
		try{
			driver.findElement(selectGHS).click();
			System.out.println("GHS option was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAmountMM() {

		try{
			driver.findElement(amountMM).click();
			System.out.println("The How much do you want to send? field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAmountMM() {

		try{
			driver.findElement(amountMM).clear();
			System.out.println("The How much do you want to send? Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmountMM (String text) {

		try{
			driver.findElement(amountMM).sendKeys(text);
			System.out.println("Amount was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectNetwork() {
		try{
			driver.findElement(selectNetwork).click();
			System.out.println("The select Network drop down field was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickMTNMobile() {
		try{
			driver.findElement(mtnMobile).click();
			System.out.println("The MTN Mobile option was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPhoneNumberMM() {

		try{
			driver.findElement(phoneNumberMM).click();
			System.out.println("The Phone Number field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearPhoneNumberMM() {

		try{
			driver.findElement(phoneNumberMM).clear();
			System.out.println("The Phone Number Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterPhoneNumberMM (String text) {

		try{
			driver.findElement(phoneNumberMM).sendKeys(text);
			System.out.println("Phone Number was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBeneficiaryName() {

		try{
			driver.findElement(beneficiaryName).click();
			System.out.println("The Beneficiary Name field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearBeneficiaryName() {

		try{
			driver.findElement(beneficiaryName).clear();
			System.out.println("The Beneficiary Name Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterBeneficiaryName (String text) {

		try{
			driver.findElement(beneficiaryName).sendKeys(text);
			System.out.println("Text was entered into the Beneficiary Name text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickDescriptionMM() {

		try{
			driver.findElement(descriptionMM).click();
			System.out.println("The Description field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearDescriptionMM() {

		try{
			driver.findElement(descriptionMM).clear();
			System.out.println("The Description Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void EnterDescriptionMM (String text) {

		try{
			driver.findElement(descriptionMM).sendKeys(text);
			System.out.println("Text was entered into the Description text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmTransferMM() {

		try{
			driver.findElement(confirmTransferMM).click();
			System.out.println("The Confirm Transfer button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmMM() {

		try{
			driver.findElement(confirmMM).click();
			System.out.println("The Confirm button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

    public void ClickTransferToBarterAccount() {

        try{
            driver.findElement(transferToBarterAccount).click();
            System.out.println("The transfer to barter account option was Clicked");

        } catch(Exception e)
        {
            throw new RuntimeException(e.getMessage());
        }
    }

    public void ClickSingleTransferBA(){

        try{
            driver.findElement(singleTransferBA).click();
            System.out.println("The single transfer option was clicked");

        } catch(Exception e)
        {
            throw new RuntimeException(e.getMessage());
        }
    }

	public void ClickMobileNumber() {

		try{
			driver.findElement(mobileNumber).click();
			System.out.println("The Mobile Number field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearMobileNumber() {

		try{
			driver.findElement(mobileNumber).clear();
			System.out.println("The Mobile Number Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterMobileNumber (String text) {

		try{
			driver.findElement(mobileNumber).sendKeys(text);
			System.out.println("Mobile Number was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAmountBA() {

		try{
			driver.findElement(amountBA).click();
			System.out.println("The How much do you want to send? field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAmountBA() {

		try{
			driver.findElement(amountBA).clear();
			System.out.println("The How much do you want to send? Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmountBA (String text) {

		try{
			driver.findElement(amountBA).sendKeys(text);
			System.out.println("Amount was entered into the How much do you want to send? text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDescriptionBA() {

		try{
			driver.findElement(descriptionBA).click();
			System.out.println("The Description field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearDescriptionBA() {

		try{
			driver.findElement(descriptionBA).clear();
			System.out.println("The Description Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDescriptionBA (String text) {

		try{
			driver.findElement(descriptionBA).sendKeys(text);
			System.out.println("Text was entered into the Description field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmTransferBA() {

		try{
			driver.findElement(confirmTransferBA).click();
			System.out.println("The Confirm Transfer button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void ClickConfirmBA(){

		try{
			driver.findElement(confirmBA).click();
			System.out.println("The Confirm button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransferToFlutterwaveAccount(){

		try{
			driver.findElement(transferToFlutterwaveAccount).click();
			System.out.println("The Transfer to Flutterwave Account button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAmountFA() {

		try{
			driver.findElement(amountFA).click();
			System.out.println("The How much do you want to send? field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAmountFA() {

		try{
			driver.findElement(amountFA).clear();
			System.out.println("The How much do you want to send? Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmountFA (String text) {

		try{
			driver.findElement(amountFA).sendKeys(text);
			System.out.println("Amount was entered into the How much do you want to send? text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickMerchantID() {

		try{
			driver.findElement(merchantID).click();
			System.out.println("The Merchant ID field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearMerchantID() {

		try{
			driver.findElement(merchantID).clear();
			System.out.println("The Merchant ID Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterMerchantID (String text) {

		try{
			driver.findElement(merchantID).sendKeys(text);
			System.out.println("Merchant ID was entered into the text field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickRequireApproval() {

		try{
			driver.findElement(requireApproval).click();
			System.out.println("The Require approval drop-down field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectedApprover() {

		try{
			driver.findElement(selectedApprover).click();
			System.out.println("An approver was selected from the  require approval drop down field");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransactionNote() {

		try{
			driver.findElement(transactionNote).click();
			System.out.println("The Transaction note field was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearTransactionNote() {

		try{
			driver.findElement(transactionNote).clear();
			System.out.println("The Transaction Note Input field was Cleared");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterTransactionNote (String text) {

		try{
			driver.findElement(transactionNote).sendKeys(text);
			System.out.println("Text was entered into the Transaction note field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmTransferFA() {

		try{
			driver.findElement(confirmTransferFA).click();
			System.out.println("The Confirm Transfer button was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmFA() {

		try{
			driver.findElement(confirmFA).click();
			System.out.println("The Confirm button was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDropDownIcon() {

		try{
			driver.findElement(dropDownIcon).click();
			System.out.println("The three dotted drop down icon  was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickApprove() {

		try{
			driver.findElement(approve).click();
			System.out.println("The Approve option was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickDisApprove() {

		try{
			driver.findElement(disapprove).click();
			System.out.println("The Disapprove option was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickViewTransferDetails() {

		try{
			driver.findElement(viewTransferDetails).click();
			System.out.println("The View Transfer Details option was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBackButton() {

		try{
			driver.findElement(backButton).click();
			System.out.println("The back button was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransferDisapproved() {
		try{
			driver.findElement(transferDisapproved).isDisplayed();
			System.out.println("Transfer has been successfully rejected is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TransferApproved() {
		try{
			driver.findElement(transferApproved).isDisplayed();
			System.out.println("Transfer has been successfully approved is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidMerchantID() {
		try{
			driver.findElement(invalidMerchantID).isDisplayed();
			System.out.println("Account not found. Please check that the Merchant ID is correct and try again. is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickGoBack() {

		try{
			driver.findElement(goBack).click();
			System.out.println("The Go Back button was clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickBulkTransferBA() {

		try{
			driver.findElement(bulkTransferBA).click();
			System.out.println("The Bulk Transfer button was Clicked");

		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
/*
	public void ClickChooseFileBA () {

		try{
			driver.findElement(chooseFileBA).sendKeys("C:/Users/HP/Documents/F4B_UI_Automation/f4b/ngn_disburse_sample.csv");
			System.out.println("Disburse File was uploaded");
		} catch(Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

 */

	public void ClickFundWallet() {
		try{
			driver.findElement(fundWallet).click();
			System.out.println("The Fund Wallet drop down field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectUSD() {
		try{
			driver.findElement(selectUSD).click();
			System.out.println("The USD currency option was was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickTransferToUSDCashPickUP() {
		try{
			driver.findElement(transferToUSDCashPickUp).click();
			System.out.println("The Transfer To USD Cash Pick-Up option was Selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickContinueBtn() {
		try{
			driver.findElement(continueBtn).click();
			System.out.println("The Continue button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickAmountField() {
		try{
			driver.findElement(amountField).click();
			System.out.println("The How much do you want to send field was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearAmountField() {

		try{
			driver.findElement(amountField).clear();
			System.out.println("The How much do you want to send? Input field was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterAmountField (String text) {

		try{
			driver.findElement(amountField).sendKeys(text);
			System.out.println("Amount was entered into the The How much do you want to send? field");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickSelectBankCashPickup() {
		try{
			driver.findElement(selectBankCashPickup).click();
			System.out.println("The Bank Name field was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickZenithBank() {
		try{
			driver.findElement(zenithBankSelected).click();
			System.out.println("Zenith Bank was selected");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
	public void ClickEmailAddressField() {
		try{
			driver.findElement(emailAddressField).click();
			System.out.println("The Email Address Field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearEmailAddressField() {

		try{
			driver.findElement(emailAddressField).clear();
			System.out.println("The Email Address was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterEmailAddressField(String text) {

		try{
			driver.findElement(emailAddressField).sendKeys(text);
			System.out.println("An email was entered into the Email Address field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickPhoneNumberField() {
		try{
			driver.findElement(phoneNumberField).click();
			System.out.println("The Phone Number Field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearPhoneNumberField() {

		try{
			driver.findElement(phoneNumberField).clear();
			System.out.println("The Phone Number was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPhoneNumberField(String text) {

		try{
			driver.findElement(phoneNumberField).sendKeys(text);
			System.out.println("A mobile number was entered into the Phone Number field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickRecipientAddress() {
		try{
			driver.findElement(recipientAddress).click();
			System.out.println("The Recipient Address Field was Clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClearRecipientAddress() {

		try{
			driver.findElement(recipientAddress).clear();
			System.out.println("The Recipient Address was Cleared");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterRecipientAddress(String text) {

		try{
			driver.findElement(recipientAddress).sendKeys(text);
			System.out.println("An address was entered into the Recipient Address field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmTransferCashPickup() {
		try{
			driver.findElement(confirmTransferCashPickup).click();
			System.out.println("The Confirm Transfer button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickConfirmBtn() {
		try{
			driver.findElement(confirmBtn).click();
			System.out.println("The Confirm  button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void InvalidNumber() {
		try{
			driver.findElement(invalidNumber).isDisplayed();
			System.out.println("An error message is displayed to user");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCancelBtn() {
		try{
			driver.findElement(cancelBtn).click();
			System.out.println("The Cancel  button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCancelBtnBA() {
		try{
			driver.findElement(cancelBtnBA).click();
			System.out.println("The Cancel  button was clicked");
		} catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}



}










