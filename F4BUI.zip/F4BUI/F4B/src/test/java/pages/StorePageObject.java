package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class StorePageObject {

	//Click on Payment Link Tab
	private By storeTab = By.xpath("//span[contains(text(),'Store')]");

	//Orders
	private By orders = By.xpath("(//div[contains(text(),\"Orders\")])[1]");
	private By filterBy = By.xpath("//span[contains(text(),'Filter By')]");
	private By today = By.xpath("(//label[contains(text(),\"Today\")])[1]");
	private By last7Days = By.xpath("(//label[contains(text(),\"Last 7 days\")])[1]");
	private By days30 = By.xpath("(//label[contains(text(),\"30 days\")])[1]");
	private By year1 = By.xpath("(//label[contains(text(),\"1 year\")])[1]");
	private By all = By.xpath("//div[contains(text(),'All')]");
	private By pending = By.xpath("//label[contains(text(),'Pending')]");
	private By successful = By.xpath("(//label[contains(text(),\"Successful\")])");
	private By cancelled = By.xpath("(//label[contains(text(),\"Cancelled\")])");
	private By done = By.xpath("(//button[contains(text(),\"Done\")])[1]");
	private By filter = By.xpath("//button[contains(text(),'Filter')]");

	//Products
	private By products = By.xpath("//div[contains(text(),'Products')]");
	private By addProduct = By.xpath("(//button[contains(text(),\"Add Product\")])[2]");
	private By productName = By.xpath("//input[@id='product-name']");
	private By productDescription = By.xpath("(//div[@class = \"ql-editor ql-blank\"])");
	private By price = By.xpath("//input[@id='product-amount']");
	private By compareAtPrice = By.xpath("//input[@id='product-compare-amount']");
	private By weight = By.xpath("//input[@id='product-weight']");
	private By numberStock = By.xpath("//input[@id='product-quantity']");
	private By saveProduct = By.xpath("(//button[contains(text(),'Save Product')])[1]");
	private By productSelect = By.xpath("//p[contains(text(),'Test')]");
	private By productOffline = By.xpath("//button[contains(text(),'Take Product Offline')]");
	private By moreActions = By.xpath("(//button[@class = \"btn btn btn--default btn--sm btn--flex\"])");
	private By deleteProduct = By.xpath("//span[contains(text(),'Delete Product')]");
	private By confirmDeleteProduct = By.xpath("//button[contains(text(),'Delete Product')]");
	private By waitingProduct = By.xpath("(//div[contains(text(),'No Product')])[2]");

	//Discount Link
	private By discountCodes = By.xpath("//div[contains(text(),'Discount Codes')]");
	private By newDiscountCode = By.xpath("//span[contains(text(),'New discount code')]");
	private By enterDiscountCode = By.xpath("//input[@id='discount-code']");
	private By discountAmount = By.xpath("(//input[@class = \"v-money form__input\"])");
	private By startDate = By.xpath("(//input[@placeholder = \"Start date\"])");
	private By clickCurrentDate = By.xpath("(//td[@class = 'curMonth today'])");
	private By backDiscounts = By.xpath("//div[contains(text(),'Discounts')]");

	//Product Categories
	private By productCategories = By.xpath("//div[contains(text(),'Product Categories')]");
	private By addNewCategory = By.xpath("//button[contains(text(),'Add new categpry')]");
	private By nameCategory = By.xpath("(//input[@class = \"form__input\"])[5]");
	private By createCategory = By.xpath("//button[contains(text(),'Create category')]");
	private By clickCategory = By.xpath("//p[contains(text(),'Game Category')]");
	private By deleteCategory = By.xpath("//button[contains(text(),'Delete')]");
	private By waitingCategory = By.xpath("//div[contains(text(),'1 product category')]");

	//Manage Store
	private By manageStore = By.xpath("//div[contains(text(),'Manage Store')]");
	private By takeStoreOnline = By.xpath("//button[contains(text(),'Take Your Store Online')]");
	private By takeStoreOffline = By.xpath("//button[contains(text(),'Take Your Store Offline')]");
	private By moreActionsManage = By.xpath("//span[contains(text(),'More Actions')]");
	private By editStore = By.xpath("//div[contains(text(),'Edit Store')]");
	private By updateStore = By.xpath("//button[contains(text(),'Update Store Details')]");
	private WebDriver driver;

	public StorePageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void ScrollUp(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, -500)");
		System.out.println("Scrolled Page Up");
	}

	public void ScrollDown(){
		//JavascriptExecutor ObjectName = (JavascriptExecutor) webdriver;
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, 500)");
		System.out.println("Scrolled Page Down");
	}

	public void NavigateDown() {
		EventFiringWebDriver eventFiringWebDriver = new EventFiringWebDriver(driver);//Create the object
		//Execute the scrolling down script using css selector element
		eventFiringWebDriver.executeScript("document.querySelector('body.nprogress-container:nth-child(2) div:nth-child(1) div.positionRelative div.padTop--50 div:nth-child(3) > nav.nav.nav--sidebar.nav--sidebar-bannerPresent:nth-child(2)').scrollTop = 400");
		System.out.println("Scrolled Inner Scroll down");
	}

	public void ClickStoreTab() {

		try{
			driver.findElement(storeTab).click();

			System.out.println("Store Tab was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Store
	public void clickOrders() {

		try{
			driver.findElement(orders).click();

			System.out.println("Orders was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void FilterBy() {

		try{
			driver.findElement(filterBy).click();

			System.out.println("Filter By Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Today() {

		try{
			driver.findElement(today).click();

			System.out.println("Today date Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Last7Days() {

		try{
			driver.findElement(last7Days).click();

			System.out.println("Last 7 Days date Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Days30() {

		try{
			driver.findElement(days30).click();

			System.out.println("Last 30 Days date Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Year1() {

		try{
			driver.findElement(year1).click();

			System.out.println("Last Year date Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void All() {

		try{
			driver.findElement(all).click();

			System.out.println("All Button was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Pending() {

		try{
			driver.findElement(pending).click();

			System.out.println("Pending was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Successful() {

		try{
			driver.findElement(successful).click();

			System.out.println("Successful was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Cancelled() {

		try{
			driver.findElement(cancelled).click();

			System.out.println("Cancelled was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Done() {

		try{
			driver.findElement(done).click();

			System.out.println("Done was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void Filter() {

		try{
			driver.findElement(filter).click();

			System.out.println("Filter Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Products
	public void Products() {

		try{
			driver.findElement(products).click();

			System.out.println("Products Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AddProducts() {

		try{
			driver.findElement(addProduct).click();

			System.out.println("Add Product Button was Clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterProductName(String text) {

		try{
			driver.findElement(productName).sendKeys(text);

			System.out.println("Product Name was entered in the text field ");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterProductDescription(String text) {

		try{
			driver.findElement(productDescription).sendKeys(text);

			System.out.println("Product Description was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterPrice(String text) {

		try{
			driver.findElement(price).sendKeys(text);

			System.out.println("Price was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterComparePrice(String text) {

		try{
			driver.findElement(compareAtPrice).sendKeys(text);

			System.out.println("Compare Price was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterWeight(String text) {

		try{
			driver.findElement(weight).sendKeys(text);

			System.out.println("Weight was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterNumberStock(String text) {

		try{
			driver.findElement(numberStock).sendKeys(text);

			System.out.println("Number of Stock was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}


	public void SaveProduct() {

		try{
			driver.findElement(saveProduct).click();

			System.out.println("Save Product Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ProductSelect() {

		try{
			driver.findElement(productSelect).click();

			System.out.println("Test Product Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ProductOffline() {

		try{
			driver.findElement(productOffline).click();

			System.out.println("Product Offline Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void MoreActions() {

		try{
			driver.findElement(moreActions).click();

			System.out.println("MoreActions Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeleteProduct() {

		try{
			driver.findElement(deleteProduct).click();

			System.out.println("Delete Product Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ConfirmDeleteProduct() {

		try{
			driver.findElement(confirmDeleteProduct).click();

			System.out.println("Confirm Delete Product Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingProduct1() {

		try{
			driver.findElement(waitingProduct).isDisplayed();

			System.out.println("Waiting for the confirm delete notification to disappear");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingProduct2() {

		try{
			driver.findElement(waitingProduct).isDisplayed();

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Discount Codes
	public void DiscountCodes() {

		try{
			driver.findElement(discountCodes).click();

			System.out.println("Discount Code Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void NewDiscountCode() {

		try{
			driver.findElement(newDiscountCode).click();

			System.out.println("New Discount Code Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterDiscountCode(String text) {

		try{
			driver.findElement(enterDiscountCode).sendKeys(text);

			System.out.println("Discount Code was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DiscountAmount(String text) {

		try{
			driver.findElement(discountAmount).sendKeys(text);

			System.out.println("Discount Amount was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void StartDate() {

		try{
			driver.findElement(startDate).click();

			System.out.println("Start Date was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCurrentDate() {

		try{
			driver.findElement(clickCurrentDate).click();

			System.out.println("Current Date was selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void BackDiscounts() {

		try{
			driver.findElement(backDiscounts).isDisplayed();

			System.out.println("Back Discount Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Product Category
	public void ProductCategories() {

		try{
			driver.findElement(productCategories).click();

			System.out.println("Product Categories Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void AddNewCategory() {

		try{
			driver.findElement(addNewCategory).click();

			System.out.println("Add New Category Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EnterNameCategory(String text) {

		try{
			driver.findElement(nameCategory).sendKeys(text);

			System.out.println("Name Category was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void CreateCategory() {

		try{
			driver.findElement(createCategory).click();

			System.out.println("Create Category Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void ClickCategory() {

		try{
			driver.findElement(clickCategory).click();

			System.out.println("Created Category Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void DeleteCategory() {

		try{
			driver.findElement(deleteCategory).click();

			System.out.println("Delete Category Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingCategory1() {

		try{
			driver.findElement(waitingCategory).isDisplayed();

			System.out.println("Waiting for the Delete Discount Notification to disappear");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void WaitingCategory2() {

		try{
			driver.findElement(waitingCategory).isDisplayed();

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Manage Store
	public void ManageStore() {

		try{
			driver.findElement(manageStore).click();

			System.out.println("Manage Store Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TakeStoreOnline() {

		try{
			driver.findElement(takeStoreOnline).click();

			System.out.println("Take Store Online Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void TakeStoreOffline() {

		try{
			driver.findElement(takeStoreOffline).click();

			System.out.println("Take Store Offline Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void MoreActionsManage() {

		try{
			driver.findElement(moreActionsManage).click();

			System.out.println("More Actions Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void EditStore() {

		try{
			driver.findElement(editStore).click();

			System.out.println("Edit Store Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void UpdateStore() {

		try{
			driver.findElement(updateStore).click();

			System.out.println("Update Store Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







